%%  DeepIntegration
clear all;
clc;
IsExistNum = exist('trackingResults.mat','file');
if ~IsExistNum
    load '.\GNSS_SDR_int8\trackingResults.mat';
    load '.\GNSS_SDR_int8\eph.mat';
    load '.\trjGeneration\Simu_trj.mat';
else
    fprintf(' ....\n');
end
%%  
InitData();  
%% 
ScalarDeepIntegration();