function att = q2att(qnb)
    att = m2att(q2cnb(qnb));