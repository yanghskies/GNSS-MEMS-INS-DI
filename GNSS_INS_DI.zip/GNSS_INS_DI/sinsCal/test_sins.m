
[qnb,vn,pos,qnb0,vn0,pos0] = nav_init(avp0(1:3),avp0(4:6),avp0(7:9),...
                                       0*[0.5;0.5;3]*glv.min, 0, 0);
[eb,web,db,wdb] = drift_bias([0;0;0;0]);
[wm,vm] = ImuAddErr(trj.imu(:,1:3)*trj.ts,trj.imu(:,4:6)*trj.ts,eb,web,db,wdb,trj.ts);
n = 1;    % 
kk = 1;
len = fix(length(wm)/n-1); err=zeros(len,9);
for k=1:n:len*n
    k1 = k+n-1;
    wme = wm(k:k1,:)';  % 
    vme = vm(k:k1,:)';
    qnb0 = a2qnb(trj.avp(k1,1:3)'); vn0=trj.avp(k1,4:6)'; pos0=trj.avp(k1,7:9)';  % 
    [qnb,vn,pos]=sins(qnb,vn,pos,wme,vme,trj.ts); 
%     vn(3) = 0;  %  
%     err(kk,:) = nav_err(qnb,vn,pos,qnb0,vn0,pos0)';
    sinsRes(kk,:) = [q2att(qnb);vn;pos];
    kk = kk+1;
    timedisp(kk,n*trj.ts,100);
end
time = [1:length(err)]*trj.ts*n;
% figure,
% subplot(3,1,1),plot(time,err(:,1:3)/glv.min), ylabel('\it\phi\rm / arcmin'); grid on
% subplot(3,1,2),plot(time,err(:,4:6)), ylabel('\it\delta V\rm / m/s');  grid on
% subplot(3,1,3),plot(time,[err(:,7:8)*glv.Re,err(:,9)]), ylabel('\it\delta P\rm / m'); grid on
% xlabel('\itt\rm / s'); 
 
figure(9)
subplot(311),plot(trj.avp(:,1)/glv.deg);hold on 
plot(sinsRes(:,1)/glv.deg);
subplot(312),plot(trj.avp(:,2)/glv.deg);hold on 
plot(sinsRes(:,2)/glv.deg);
subplot(313),plot(unwrap(trj.avp(:,3))/glv.deg);hold on 
plot(unwrap(sinsRes(:,3))/glv.deg);
figure(10)
plot(sinsRes(:,7)/glv.deg,sinsRes(:,8)/glv.deg);hold on
plot(trj.avp(:,7)/glv.deg,trj.avp(:,8)/glv.deg);
