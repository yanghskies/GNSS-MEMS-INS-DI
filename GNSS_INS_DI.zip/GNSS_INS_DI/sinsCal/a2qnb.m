function qnb = a2qnb(att)
    qnb = m2qnb(a2cnb(att));