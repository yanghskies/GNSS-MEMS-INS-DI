function qo = qconj(qi)
    qo = [qi(1); -qi(2:4)];