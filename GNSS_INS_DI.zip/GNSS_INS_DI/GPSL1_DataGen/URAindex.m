function num=URAindex(ura)
%���뾫ȷ�ȣ�����URA index 
%URA INDEX URA (meters)
% 0 0.00 < URA �� 2.40
% 1 2.40 < URA �� 3.40
% 2 3.40 < URA �� 4.85
% 3 4.85 < URA �� 6.85
% 4 6.85 < URA �� 9.65
% 5 9.65 < URA �� 13.65
% 6 13.65 < URA �� 24.00
% 7 24.00 < URA �� 48.00
% 8 48.00 < URA �� 96.00
% 9 96.00 < URA �� 192.00
% 10 192.00 < URA �� 384.00
% 11 384.00 < URA �� 768.00
% 12 768.00 < URA �� 1536.00
% 13 1536.00 < URA �� 3072.00
% 14 3072.00 < URA �� 6144.00
% 15 6144.00 < URA

if ura>0 && ura<=2.4
    num=0;
elseif ura>2.4 && ura<=3.4
    num=1;
elseif ura>3.4 && ura<=4.85
    num=2;
elseif ura>4.85 && ura<=6.85
    num=3;
elseif ura>6.85 && ura<=9.65
    num=4;
elseif ura>9.65 && ura<=13.65
    num=5;
elseif ura>13.65 && ura<=24.00
    num=6;
elseif ura>24.00 && ura<=48.00
    num=7;
elseif ura>48.00 && ura<=96.00
    num=8;
elseif ura>96.00 && ura<=192.00
    num=9;
elseif ura>192.00 && ura<=384
    num=10;
elseif ura>384 && ura<=768
    num=11;    
elseif ura>768 && ura<=1536
    num=12;    
elseif ura>1536 && ura<=3072
    num=13;
elseif ura>3072 && ura<=6144
    num=14;
else
    num=15;
end;