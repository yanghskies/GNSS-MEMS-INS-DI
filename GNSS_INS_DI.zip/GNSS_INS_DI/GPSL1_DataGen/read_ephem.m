function [head,leap,alm]=read_ephem(filename)
%filename='brdc0740.07n';
fid=fopen(filename);

if fid==0
    error([filename,' does not exist'])
end
for i=1:3
    s=fgetl(fid);
end
for i=1:3
    s=fgetl(fid);
    head(i,1:4)=(sscanf(s,'%e'))'; 
end
s=fgetl(fid);
leap=sscanf(s,'%e'); 
s=fgetl(fid);%  End of header

i=0;    
s=fgetl(fid);

while ischar(s) 
  if ~isempty(s)
      i=i+1;
      alm(i,1:10)=(sscanf(s,'%e'))';                 %��һ������PRN / EPOCH / SV CLK
      for j=0:6 
         s=fgetl(fid);
         alm(i,10+4*j+1:10+4*j+4)=(sscanf(s,'%e'))'; %����������
      end
   end
   s=fgetl(fid);
end
fclose(fid);
return

