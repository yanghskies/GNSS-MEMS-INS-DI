function word2=parityencode(word,D29star,D30star)
% 6bit У��λ������
% input:
%     word:ǰ24bit
%     D29star:ǰһ��word��29λ
%     D30star:ǰһ��word��30λ
% output:
%     word(1:30):����У������word
    
% word:
word2(1:24)=word(1:24);
if D30star == 1
    % Data bits must be inverted
    word2(1:24) = bitxor(word(1:24),ones(1,24));
end

word2(25)=mod(D29star+word(1)+word(2)+word(3)+word(5)+word(6)+word(10)+word(11)+word(12)+word(13)+word(14)+word(17)+word(18)+word(20)+word(23),2);
word2(26)=mod(D30star+word(2)+word(3)+word(4)+word(6)+word(7)+word(11)+word(12)+word(13)+word(14)+word(15)+word(18)+word(19)+word(21)+word(24),2);
word2(27)=mod(D29star+word(1)+word(3)+word(4)+word(5)+word(7)+word(8)+word(12)+word(13)+word(14)+word(15)+word(16)+word(19)+word(20)+word(22),2);
word2(28)=mod(D30star+word(2)+word(4)+word(5)+word(6)+word(8)+word(9)+word(13)+word(14)+word(15)+word(16)+word(17)+word(20)+word(21)+word(23),2);
word2(29)=mod(D30star+word(1)+word(3)+word(5)+word(6)+word(7)+word(9)+word(10)+word(14)+word(15)+word(16)+word(17)+word(18)+word(21)+word(22)+word(24),2);
word2(30)=mod(D29star+word(3)+word(5)+word(6)+word(8)+word(9)+word(10)+word(11)+word(13)+word(15)+word(19)+word(22)+word(23)+word(24),2);
return


