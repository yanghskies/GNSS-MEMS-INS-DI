%gps L1 simulation
function gpsL1_gen_test(despath,userPos,bitset)
%*****  �����������*******************************************************
local = [2014,02,26,15,00,4];% start simulation time, must be times of 6 seconds
Fs = 2.5e6; % ������ 5e6
step = 1/200; % ���沽�� 1/100
PosNum = size(userPos,1);%/100;
RunTime = (PosNum-1)*step; % ����ʱ��
xx= 0:step:RunTime;N = length(xx);
timezone = 0; C = 2.99792458e8;
FL1 = 1575.42e6; CA_rate = 1.023e6; mask = 10;%17��
% filename = 'brdc1690.07n';% �����ļ�
filename = 'base.nav';% �����ļ�
% B = 34;L = 116;H = 70;  %�û���ʼλ��
User = zeros(N,3);
for k = 1:N
    B = userPos(k,1)/pi*180; % γ��
    L = userPos(k,2)/pi*180; % ����
    H = userPos(k,3);
    [User(k,1),User(k,2),User(k,3)] = lla2ecef(B,L,H);% ת��ΪECEF����ϵ
end

%******************  �û��켣  ********************************************
[GPSweek,GPSsecs,epochdelta] = l2gpstime(local,timezone);% ����ʱ��ת��GPSʱ
User_sec = GPSsecs + xx; User_week = GPSweek.*ones(1,N);
User_xyz(:,1:2) = [User_week' User_sec'];
User_xyz(:,3:5) = User;% ���û�λ����ϳɹ̶���ʽ����һ���������ڶ���������������������xyz
                                      % ÿһ�ж�Ӧһ������ʱ���û�λ��
                                                                           
%******************  ���ǹ켣  *********************************************
[~,~,ephem]=read_ephem(filename);% �������ļ�
ephem_time = ephem(:,5:7);%  ȡ��ʱ���֡���
% n = find((local(4)- ephem(:,5)==0 & local(5) >= ephem(:,6))| local(4)-ephem(:,5)==1 ...
%     | (ephem(:,6)==59 & local(4)-ephem(:,5)==2));%�������������
% ephem0 = ephem(n,:);
% for i=1:31
%      l=find(ephem0(:,1)==i);% �ҳ���ͬ�����Ǻ�i���ڵ�����ֵ
%      if(length(l)>1)%���������������ͬ���Ǻ�
%          ephem0(l(1),:)=zeros(1,38);%���ǵ�59�ֵ����,����������,��ǰ����һ��Ϊ��,Ȼ���˵�
%      end
% end
% ephem1=ephem0((ephem0(:,1)~=0),:);%�ҵ���������ݶ�,����ʱ���ڵ��������ǵ�����

% n = find((local(4)- ephem(:,5)==0 & local(5) >= ephem(:,6))| local(4)-ephem(:,5)==1 ...
%     | (ephem(:,6)==59 & local(4)-ephem(:,5)==2));%�������������
% ephem0 = ephem(n,:);
ephem0 = ephem;
for i=1:31
     l=find(ephem0(:,1)==i);% �ҳ���ͬ�����Ǻ�i���ڵ�����ֵ
     if(length(l)>1)%���������������ͬ���Ǻ�
         for ii = 1:length(l)-1
             ephem0(l(ii),:)=zeros(1,38);
         end
     end
end
ephem1=ephem0((ephem0(:,1)~=0),:);%�ҵ���������ݶ�,����ʱ���ڵ��������ǵ�����

     %***********   ����ɼ����� **************
[H0,PRN0,AZ0,EL0] = cal_visual_sv(User_xyz(1,3:5),epochdelta,mask,ephem1,timezone);%���濪ʼʱ���ҵ���������
epochdelta_n=epochdelta+RunTime;
[H,PRNn,AZ,EL] = cal_visual_sv(User_xyz(N,3:5),epochdelta_n,mask,ephem1,timezone);%�������ʱ���ҵ���������
prn_sv=intersect(PRN0,PRNn);% ������
%save prn_sv prn_sv;

%************   ���ɵ������� **************
num_prns = length(prn_sv);
Eph = zeros(num_prns,38);
nr_nav = ceil(RunTime/6);
framep1 = zeros(num_prns,1800*nr_nav);%300*6
for i=1:num_prns             
    Num=find(ephem1(:,1)==prn_sv(i));%�ҵ���Ӧ�����Ǻ�
    Eph(i,:) = ephem1(Num,:);        %���ſɼ����Ƕ�Ӧ������
    for k = 1:nr_nav
        framep1(i,(k-1)*1800+1:k*1800)=ephem2bintotal(GPSsecs+(k-1)*36,ephem1,Num);
    end
end

NavFram(((framep1==1))) = -1;
NavFram(((framep1==0))) = 1;
NavFram = reshape(NavFram,size(framep1));
NavFram = [NavFram ones(size(NavFram,1),100)];
    %*****************************************
col1 = ones(num_prns,1)*User_week;  % ��һ��GPS������ t1 t1 ...t1 t2 t2...t2  
col2 = ones(num_prns,1)*User_sec;   % �ڶ���GPS������ t1 t1 ...t1 t2 t2...t2  
col3 = prn_sv*ones(1,N);            % ���������Ǻţ�
sv_pos_mat = zeros(N*num_prns,6);
sv_v = zeros(N*num_prns,4);
sv_pos_mat(:,1:3) = [col1(:) col2(:) col3(:)];
sv_v(:,1:3) = sv_pos_mat(:,1:3);
sv_clk_er(:,1) = sv_pos_mat(:,3);

for i = 1:N
    strt = (1+(i-1)*num_prns);              %��ʼλ��
    stp = (num_prns+(i-1)*num_prns);        %��ֹλ��
    transmit_time_vec = ones(num_prns,1)*(epochdelta+(i-1)*step-0.07);%����ʱ�����У�����ʱ��Ĭ��Ϊ0.07s����0.07s֮ǰ�����ź�
    true_recv_pos = User_xyz(i,3:5);        %���ջ�λ��
    max_Los_err = 41;                       %������޳�ʼ��
    kk=0;
    while max_Los_err >1;  %�����㷨��ͨ������ʱ�䣬�����ҵ���ȷ�����Ƿ���ʱ��
        %����ÿһ�ſɼ��ǵ�λ���ٶ�
        for n =1:num_prns
            [sv_pos_mat(strt+n-1,4:6) sv_v(strt+n-1,4:6) sv_clk_er(strt+n-1,2)]=ephem2pos(Eph(n,:),transmit_time_vec(n),timezone);
        end
        prop_times = ((sum(((sv_pos_mat(strt:stp,4:6)-ones(num_prns,1)*true_recv_pos).^2),2)).^0.5)./C;% ���ƵĴ���ʱ��
        new_transmit_time_vec = ones(num_prns,1)*(epochdelta+(i-1)*step) - prop_times;
        max_Los_err = max(abs(transmit_time_vec - new_transmit_time_vec ))*C;
        transmit_time_vec = new_transmit_time_vec;    
        if(kk>100)
            break;
        else
            kk=kk+1;
        end
    end
    prop_time(strt:stp,2) = prop_times;
end

prop_time(:,1) = sv_pos_mat(:,3); % �õ�ÿ������ʱ�̵����Ǻ�

Sat_clk_er = zeros(num_prns,N);
tranvse_time = zeros(num_prns,N);
for i = 1:num_prns
    sv_index = find(sv_pos_mat(:,3)==prn_sv(i));
    temp = sv_clk_er(sv_index,2)';
    Sat_clk_er(i,:) = temp;
    tranvse_time(i,:) = (prop_time(sv_index,2)');
end
t_temp = [prn_sv tranvse_time];

%******  ������ʱ�̵�����λ����ת������ʱ�̵�����ϵ�У�Ȼ�����ͬһ������ϵ�е�����λ�ú�
%******���û�λ�ü��㴫��ʱ�䣨�ޣ���ΪӦ�������ʱ��ȥ�ɼ��룩��
range_prn = zeros(num_prns,N);
mod_SatP = zeros(num_prns,N*3);
for index = 1:N
    SatP = sv_pos_mat((index-1)*num_prns+1:index*num_prns,4:6);
    UserP = repmat(User_xyz(index,3:5),num_prns,1);
    % ������ת����
    for i = 1:num_prns
        SatP(i,:) = EarthRotation(t_temp(i,index+1),SatP(i,:));
    end
  
    range_prn(:,index) = sqrt( sum((SatP - UserP).^2,2) );
    mod_SatP(1:num_prns,index:index+2) = SatP; 
end

tranvse_time = range_prn./C - Sat_clk_er;

%**********  �źŲ������� *********************
Ts = 1/Fs;Tc = 1/CA_rate;
t0 = 0;Log = step;PINT = 1; number_step = Fs*Log;
load ca;
CA = -CA;

SNR = -15;
% NoiseP_dB = -201;
NoiseP_dB = -174;
amplitude =sqrt(2* 10^((SNR+NoiseP_dB)/10));
NoiseP = sqrt(2*10^(NoiseP_dB)/10);




head_dat = [local(1)-1900 local(2) local(3:end) RunTime *50 5 length(prn_sv)-1 prn_sv' zeros(1,55-length(prn_sv))];



% filename1='h:\gps_sim_signal_20090109_';
filename1=despath;
filename2='gpsL1_';
filename3=num2str(RunTime);    
filename4='s_'; 
filename5=num2str(bitset);
filename6='bit.raw';
fid = fopen(strcat(filename1,filename2,filename3,filename4,filename5,filename6),'w');

fwrite(fid,head_dat,'int32');

diff_Tp = diff(tranvse_time,1,2); % ʹ�ô���ʱ��Ϊ��һ�м�ǰһ��

%tic
while t0 < RunTime
    display(t0);    
    time = t0:Ts:PINT*Log-Ts;
    M = length(time);
    temp = diff_Tp(:,PINT)./number_step;
    Tp_vec = tranvse_time(:,PINT)*ones(1,number_step)+temp*(0:number_step-1);
    com_sig = zeros(1,M);
    for i = 1:num_prns
        %********* carrier **************************
%         TRUE_REF = - 2*pi*FL1.*Tp_vec(i,:);
%         TRUE_REF = mod(TRUE_REF,2*pi);
        %*****************�ز�����C�������� ***************************
%         [cos_dat sin_dat] = modulation(Tp_vec(i,:),FL1);%[cos_dat sin_dat] = modulation(Tp_vec(i,:),FL1);
        
        CarSig = 2*pi*Tp_vec(i,:).*FL1;
        CarSig = mod(CarSig,2*pi);
        cos_dat = cos(CarSig);
        sin_dat = sin(CarSig);
        %temp1 = cos_dat + j*sin_dat;
        %******  pseudocode *****************************
        send_time = time - Tp_vec(i,:);        
        
        %***** time_dyn = mod(send_time,0.001);
        %** �Ż� time_dyn = mod(send_time,0.001)********
        time_dyn = send_time*1000;
        time_dyn = time_dyn - fix(time_dyn);
        time_dyn(time_dyn<0) = time_dyn(time_dyn<0) + 1;
        time_dyn = time_dyn./1000;        
        
        %***********************************************
        chip_num = fix(time_dyn./Tc)+1;
        temp = CA(prn_sv(i),:);
        tcode = temp(chip_num);
        %************************************************      
%       %*******  navigation data ******************** 
        last_negative_time = find(send_time<0,1,'last');%find the last negative time index
        if  last_negative_time
            negative_time_len = length(last_negative_time);
            if last_negative_time == number_step
                NavDat = ones(1,negative_time_len );
            else                
                Negative_NavDat = ones(1,last_negative_time);
                postive_time = send_time(last_negative_time+1:end);
                chip_num = fix(postive_time.*50)+1;
                temp = NavFram(i,:);
                NavDat = [Negative_NavDat temp(chip_num)];
            end
            
        else
            chip_num = fix(send_time.*50) + 1;
            temp = NavFram(i,:);
            NavDat = temp(chip_num);
        end
        %************************************************
        temp2 = NavDat.*tcode;
        temp3 =temp2.*cos_dat + 1j*temp2.*sin_dat; 
        
%         sig = amplitude*temp3 + wgn(1,M,NoiseP_dB,'complex');%*NoiseP;
%         com_sig = (com_sig+sig*10^7);  

            % G:
%         if(prn_sv(i)==7||prn_sv(i)==21) %��������ȣ�10*log10(alpha^2/(Pn^2/Settings.B))��int8�������ܴ���1dB��ʧ
%             if(t0<=50)
%                 sig = 0.6*temp3;
%             elseif(t0>50&&t0<=100)
%                 sig = (0.6-(0.6-0.1)*(t0-50)/50)*temp3;
%             elseif(t0>100&&t0<=250)
%                 sig = 0.1*temp3; %10*log10(0.1^2/(4^2/(2.5e6/2))) = 28.9279003035213
%             elseif(t0>250&&t0<300)
%                 sig = (0.1+(0.6-0.1)*(t0-250)/50)*temp3;
%             elseif(t0>300&&t0<350)
%                 sig = 0.6*temp3; 
%             elseif(t0>350&&t0<400)
%                 sig = (0.6-(0.6-0.06)*(t0-350)/50)*temp3;
%             elseif(t0>400&&t0<550)
%                 sig = 0.06*temp3; %10*log10(0.06^2/(4^2/(2.5e6/2))) = 24.4909253111942
%             elseif(t0>550&&t0<600)
%                 sig = (0.06+(0.6-0.06)*(t0-550)/50)*temp3;
%             elseif(t0>600&&t0<700)
%                 sig = 0.6*temp3;
%             elseif(t0>700&&t0<750)
%                 sig = (0.6-(0.6-0.03)*(t0-700)/50)*temp3;
%             elseif(t0>750&&t0<900)
%                 sig = 0.03*temp3; %10*log10(0.03^2/(4^2/(2.5e6/2))) = 18.4703253979146
%             elseif(t0>900&&t0<950)
%                 sig = (0.03+(0.6-0.03)*(t0-900)/50)*temp3;
%             elseif(t0>950)
%                 sig = 0.6*temp3;
%             end
%         else
%             sig = 0.6*temp3;
%         end

        % E:
%         if(prn_sv(i)==7||prn_sv(i)==21) %��������ȣ�10*log10(alpha^2/(Pn^2/Settings.B))��int8�������ܴ���1dB��ʧ
%             if(t0<=50)
%                 sig = 0.6*temp3;
%             elseif(t0>50&&t0<=100)
%                 sig = (0.6-(0.6-0.1)*(t0-50)/50)*temp3;
%             elseif(t0>100&&t0<=200)
%                 sig = 0.1*temp3; %10*log10(0.1^2/(4^2/(2.5e6/2))) = 28.9279003035213
%             elseif(t0>200&&t0<250)
%                 sig = (0.1+(0.6-0.1)*(t0-200)/50)*temp3;
%             elseif(t0>250&&t0<300)
%                 sig = 0.6*temp3; 
%             elseif(t0>300&&t0<350)
%                 sig = (0.6-(0.6-0.065)*(t0-300)/50)*temp3;
%             elseif(t0>350&&t0<450)
%                 sig = 0.065*temp3; %10*log10(0.065^2/(4^2/(2.5e6/2))) = 25.1861674363784
%             elseif(t0>450&&t0<500)
%                 sig = (0.065+(0.6-0.065)*(t0-450)/50)*temp3;
%             elseif(t0>500&&t0<550)
%                 sig = 0.6*temp3;
%             end
%         else
%             sig = 0.6*temp3;
%         end

%             % F:
%         if t0==0
%             for ii=1:11
%                 alpha(ii) = sqrt(10^((28-ii)/10)*(4^2/(2.5e6/2)));
%             end
%         end
%         if(prn_sv(i)==7||prn_sv(i)==21) %��������ȣ�10*log10(alpha^2/(Pn^2/Settings.B))��int8�������ܴ���1dB��ʧ.��������ȼ���������sqrt(10^(CN0/10)*(4^2/(2.5e6/2)))
%             if(t0<=50)
%                 sig = 1.8*temp3;
%             elseif(t0>50&&t0<=70)
%                 sig = (1.8-(1.8-alpha(1))*(t0-50)/20)*temp3;
%             elseif(t0>70&&t0<=80)
%                 sig = alpha(1)*temp3; 
%             elseif(t0>80&&t0<90)
%                 sig = (alpha(1)+(0.6-alpha(1))*(t0-80)/10)*temp3;
%             elseif(t0>90&&t0<100)
%                 sig = 0.6*temp3; 
%             elseif(t0>100&&t0<=110)
%                 sig = (0.6-(0.6-alpha(2))*(t0-100)/10)*temp3;
%             elseif(t0>110&&t0<=130)
%                 sig = alpha(2)*temp3; 
%             elseif(t0>130&&t0<140)
%                 sig = (alpha(2)+(0.6-alpha(2))*(t0-130)/10)*temp3;
%             elseif(t0>140&&t0<150)
%                 sig = 0.6*temp3; 
%             elseif(t0>150&&t0<=160)
%                 sig = (0.6-(0.6-alpha(3))*(t0-150)/10)*temp3;
%             elseif(t0>160&&t0<=180)
%                 sig = alpha(3)*temp3; 
%             elseif(t0>180&&t0<190)
%                 sig = (alpha(3)+(0.6-alpha(3))*(t0-180)/10)*temp3;
%             elseif(t0>190&&t0<200)
%                 sig = 0.6*temp3;     
%             elseif(t0>200&&t0<=210)
%                 sig = (0.6-(0.6-alpha(4))*(t0-200)/10)*temp3;
%             elseif(t0>210&&t0<=230)
%                 sig = alpha(4)*temp3; 
%             elseif(t0>230&&t0<240)
%                 sig = (alpha(4)+(0.6-alpha(4))*(t0-230)/10)*temp3;
%             elseif(t0>240&&t0<250)
%                 sig = 0.6*temp3; 
%             elseif(t0>250&&t0<=260)
%                 sig = (0.6-(0.6-alpha(5))*(t0-250)/10)*temp3;
%             elseif(t0>260&&t0<=280)
%                 sig = alpha(5)*temp3; 
%             elseif(t0>280&&t0<290)
%                 sig = (alpha(5)+(0.6-alpha(5))*(t0-280)/10)*temp3;
%             elseif(t0>290&&t0<300)
%                 sig = 0.6*temp3; 
%             elseif(t0>300&&t0<=310)
%                 sig = (0.6-(0.6-alpha(6))*(t0-300)/10)*temp3;
%             elseif(t0>310&&t0<=330)
%                 sig = alpha(6)*temp3; 
%             elseif(t0>330&&t0<340)
%                 sig = (alpha(6)+(0.6-alpha(6))*(t0-330)/10)*temp3;
%             elseif(t0>340&&t0<350)
%                 sig = 0.6*temp3; 
%             elseif(t0>350&&t0<=360)
%                 sig = (0.6-(0.6-alpha(7))*(t0-350)/10)*temp3;
%             elseif(t0>360&&t0<=380)
%                 sig = alpha(7)*temp3; 
%             elseif(t0>380&&t0<390)
%                 sig = (alpha(7)+(0.6-alpha(7))*(t0-380)/10)*temp3;
%             elseif(t0>390&&t0<400)
%                 sig = 0.6*temp3; 
%             elseif(t0>400&&t0<=410)
%                 sig = (0.6-(0.6-alpha(8))*(t0-400)/10)*temp3;
%             elseif(t0>410&&t0<=430)
%                 sig = alpha(8)*temp3; 
%             elseif(t0>430&&t0<440)
%                 sig = (alpha(8)+(0.6-alpha(8))*(t0-430)/10)*temp3;
%             elseif(t0>440&&t0<450)
%                 sig = 0.6*temp3; 
%             elseif(t0>450&&t0<=460)
%                 sig = (0.6-(0.6-alpha(9))*(t0-450)/10)*temp3;
%             elseif(t0>460&&t0<=480)
%                 sig = alpha(9)*temp3; 
%             elseif(t0>480&&t0<490)
%                 sig = (alpha(9)+(0.6-alpha(9))*(t0-480)/10)*temp3;
%             elseif(t0>490&&t0<500)
%                 sig = 0.6*temp3; 
%             elseif(t0>500&&t0<=510)
%                 sig = (0.6-(0.6-alpha(10))*(t0-500)/10)*temp3;
%             elseif(t0>510&&t0<=530)
%                 sig = alpha(10)*temp3; 
%             elseif(t0>530&&t0<540)
%                 sig = (alpha(10)+(0.6-alpha(10))*(t0-530)/10)*temp3;
%             elseif(t0>540&&t0<550)
%                 sig = 0.6*temp3; 
%             end
%         else
%             if(t0<=50)
%                 sig = 1.8*temp3;
%             elseif(t0>50&&t0<=70)
%                 sig = (1.8-(1.8-0.6)*(t0-50)/20)*temp3;
%             else
%                 sig = 0.6*temp3;
%             end
% %             sig = 0.6*temp3;
%         end

 % F:  11G
        if t0==0
            for ii=1:11
                alpha(ii) = sqrt(10^((14-ii)/10)*(4^2/(2.5e6/2)));
            end
        end
        if(prn_sv(i)==57||prn_sv(i)==521) %��������ȣ�10*log10(alpha^2/(Pn^2/Settings.B))��int8�������ܴ���1dB��ʧ.��������ȼ���������sqrt(10^(CN0/10)*(4^2/(2.5e6/2)))
            if(t0<=50)
                sig = 0.6*temp3;
            elseif(t0>50&&t0<=70)
                sig = (0.6-(0.6-alpha(1))*(t0-50)/20)*temp3;
            elseif(t0>70&&t0<=80)
                sig = alpha(1)*temp3; 
            elseif(t0>80&&t0<=90)
                sig = (alpha(1)+(0.6-alpha(1))*(t0-80)/10)*temp3;
            elseif(t0>90&&t0<=100)
                sig = 0.6*temp3; 
            elseif(t0>100&&t0<=110)
                sig = (0.6-(0.6-alpha(2))*(t0-100)/10)*temp3;
            elseif(t0>110&&t0<=130)
                sig = alpha(2)*temp3; 
            elseif(t0>130&&t0<=140)
                sig = (alpha(2)+(0.6-alpha(2))*(t0-130)/10)*temp3;
            elseif(t0>140&&t0<=150)
                sig = 0.6*temp3; 
            elseif(t0>150&&t0<=160)
                sig = (0.6-(0.6-alpha(3))*(t0-150)/10)*temp3;
            elseif(t0>160&&t0<=180)
                sig = alpha(3)*temp3; 
            elseif(t0>180&&t0<=190)
                sig = (alpha(3)+(0.6-alpha(3))*(t0-180)/10)*temp3;
            elseif(t0>190&&t0<=200)
                sig = 0.6*temp3;     
            elseif(t0>200&&t0<=210)
                sig = (0.6-(0.6-alpha(4))*(t0-200)/10)*temp3;
            elseif(t0>210&&t0<=230)
                sig = alpha(4)*temp3; 
            elseif(t0>230&&t0<=240)
                sig = (alpha(4)+(0.6-alpha(4))*(t0-230)/10)*temp3;
            elseif(t0>240&&t0<=250)
                sig = 0.6*temp3; 
            elseif(t0>250&&t0<=260)
                sig = (0.6-(0.6-alpha(5))*(t0-250)/10)*temp3;
            elseif(t0>260&&t0<=280)
                sig = alpha(5)*temp3; 
            elseif(t0>280&&t0<=290)
                sig = (alpha(5)+(0.6-alpha(5))*(t0-280)/10)*temp3;
            elseif(t0>290&&t0<=300)
                sig = 0.6*temp3; 
            elseif(t0>300&&t0<=310)
                sig = (0.6-(0.6-alpha(6))*(t0-300)/10)*temp3;
            elseif(t0>310&&t0<=330)
                sig = alpha(6)*temp3; 
            elseif(t0>330&&t0<=340)
                sig = (alpha(6)+(0.6-alpha(6))*(t0-330)/10)*temp3;
            elseif(t0>340&&t0<=350)
                sig = 0.6*temp3; 
            elseif(t0>350&&t0<=360)
                sig = (0.6-(0.6-alpha(7))*(t0-350)/10)*temp3;
            elseif(t0>360&&t0<=380)
                sig = alpha(7)*temp3; 
            elseif(t0>380&&t0<=390)
                sig = (alpha(7)+(0.6-alpha(7))*(t0-380)/10)*temp3;
            elseif(t0>390&&t0<=400)
                sig = 0.6*temp3; 
            elseif(t0>400&&t0<=410)
                sig = (0.6-(0.6-alpha(8))*(t0-400)/10)*temp3;
            elseif(t0>410&&t0<=430)
                sig = alpha(8)*temp3; 
            elseif(t0>430&&t0<=440)
                sig = (alpha(8)+(0.6-alpha(8))*(t0-430)/10)*temp3;
            elseif(t0>440&&t0<=450)
                sig = 0.6*temp3; 
            elseif(t0>450&&t0<=460)
                sig = (0.6-(0.6-alpha(9))*(t0-450)/10)*temp3;
            elseif(t0>460&&t0<=480)
                sig = alpha(9)*temp3; 
            elseif(t0>480&&t0<=490)
                sig = (alpha(9)+(0.6-alpha(9))*(t0-480)/10)*temp3;
            elseif(t0>490&&t0<=500)
                sig = 0.6*temp3; 
            elseif(t0>500&&t0<=510)
                sig = (0.6-(0.6-alpha(10))*(t0-500)/10)*temp3;
            elseif(t0>510&&t0<=530)
                sig = alpha(10)*temp3; 
            elseif(t0>530&&t0<=540)
                sig = (alpha(10)+(0.6-alpha(10))*(t0-530)/10)*temp3;
            elseif(t0>540&&t0<=550)
                sig = 0.6*temp3; 
            end
        else
            sig = 0.6*temp3;
        end
        
%         sig = temp3;
        com_sig = (com_sig+sig);      
    end
    com_sig = com_sig + 4.*randn(M,1)' + 1j*4.*randn(M,1)';
    com_sig = 12.8*com_sig;
    
%*** ���ڸ��ź�д�ļ� *****************
    %% int8���
    real_sig = int8(round(real(com_sig)));
    imag_sig = int8(round(imag(com_sig)));
    real_sig = quantibit(real_sig,bitset);
    imag_sig = quantibit(imag_sig,bitset);
    com_sig = reshape([imag_sig;real_sig],1,length(real_sig)*2);
    fwrite(fid,com_sig,'int8');
    %% double ���
%     real_sig = real(com_sig);
%     imag_sig = imag(com_sig);
%     com_sig = reshape([imag_sig;real_sig],1,length(real_sig)*2);
%     fwrite(fid,com_sig,'double');
    
    t0 = time(end)+Ts;
    PINT = PINT+1;
    clear time com_sig sig real_sig imag_sig;

end
%toc
fclose(fid);        






        

