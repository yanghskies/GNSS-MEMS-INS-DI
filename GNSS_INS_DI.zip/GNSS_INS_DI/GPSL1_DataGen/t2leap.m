function [leapsecs] = t2leap(time)

% leapsecs = t2leap(time)
%
% Look up leap seconds in a table
% �ڱ����в�������
% 
% Input. time: A matrix with 2 or 6 columns,
%              2 columns are interpreted as GPS time: [GPS week, GPS secs]
%              6 columns are interpreted as UTC time: [year, month, day, hours, mins, secs]
%
% Output.leapsecs: leapsecs(i) = number of leap seconds that had occurred by time(i,:)
%
% The function looks up the time and number of leap seconds from a configuration file
% called UTC_LEAP.CFG which must be in the Matlab path.

DAYSEC  = 86400;
WEEKSEC = 604800;

[m,n] = size(time);
if (n==1), 
  time=time';
  [m,n] = size(time);
end
if (n~=2) && (n~=6)
  error('time input must have 2 or 6 columns');
end
                             
% open the UTC leap configuration text file which contains the UTC times
% of when leap seconds were added.

% From the file, we will create UTCtable, which  contains UTC times (in
% the form of  [year, month, day, hours, mins, secs]). At each of these
% times a leap second occurred
         
fid=fopen('utc_leap.cfg','rt');
if fid == -1
   error('Could not find the UTC_LEAP.CFG file in the current path!');
else
   UTCtable = [];
   while ~feof(fid)
      line = fgetl(fid);
      if line ~= -1
         UTCtable = [UTCtable;sscanf(line,'%f/%f/%f %f:%f:%f')'];
      end
   end
   fclose(fid);
   % rearrange the table from month/day/year to year/month/day
   UTCtable(:,[1 2 3]) = UTCtable(:,[3 1 2]);
end

if (n==2)
  % create a table of the GPS times at which leap seconds occurred
  GPStable = l2gpstime(UTCtable);
  table = GPStable(:,1)*WEEKSEC + GPStable(:,2); 
  tsecs = time(:,1)*WEEKSEC + time(:,2);              
  %table and tsecs now contain number of seconds since the GPS epoch
else      
  days = julian(UTCtable(:,1),UTCtable(:,2),UTCtable(:,3)); % num days since 1980,1,1
  table = [days(:)*DAYSEC + UTCtable(:,4)*3600 + UTCtable(:,5)*60 + UTCtable(:,6)];
  tsecs = DAYSEC*julian(time(:,1),time(:,2),time(:,3)) + time(:,4)*3600 + time(:,5)*60 + time(:,6);
  % table and time now contain number of seconds since 1980,1,1
end

leapsecs=zeros(m,1);
for i=1:m
  leapsecs(i) = sum(table<=tsecs(i));
end
