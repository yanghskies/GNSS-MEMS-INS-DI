function subframep1=ephem2bintotal(GPS_sec,ephem,i)
%��β�����ӵ�һ֡ѭ��
%http://cddisa.gsfc.nasa.gov/pub/gps/gpsdata/04013/04d/brdc0130.04n.Z
% �ó����RINEX��ʽ�������ж�ȡ�������������յ������ĵĸ�ʽ���뵽֡�ڣ����������ʸ��
% ʸ�����ݱ��浽sub123.mat,Ŀǰֻ����ͬһʱ����ڵ�һ�����ǵ�ǰ������֡�Ľ��
% ���ϵ�4��֡�͵�����֡�ĵ�һҳ
% ������Ҫ��������m�ļ���dec2comp.m, URAindex.m,parityencode.m
 
% Pi used in the GPS coordinate system
    gpsPi = 3.1415926535898; 
        
    WN=fliplr(dec2binvec(mod(ephem(i,29),1024),10));%GPS��������module 1024��ת�ɶ�����ʸ��֮�󣬸ߵ�λ����
    
    URA=fliplr(dec2binvec(URAindex(ephem(i,31)),4)); 
    CodeL2=fliplr(dec2binvec(ephem(i,28),2));    
    L2P=fliplr(dec2binvec(ephem(i,30),1));    
    health=fliplr(dec2binvec(ephem(i,32),6));
    IODC=fliplr(dec2binvec(ephem(i,34),10));
    tgd=dec2comp(fix(ephem(i,33)*2^31),8);  %*����ʾת�ɴ���sign bit�Ķ�����ʸ����1Ϊ������0Ϊ����
    toe=fliplr(dec2binvec(fix(ephem(i,19)/2^4),16));
    a_f2=dec2comp(fix(ephem(i,10)*2^55),8);    %*��ͬ��
    a_f1=dec2comp(fix(ephem(i,9)*2^43),16);    %*
    a_f0=dec2comp(fix(ephem(i,8)*2^31),22);    %*
    
    IODE=fliplr(dec2binvec(ephem(i,11),8));
    Crs=dec2comp(fix(ephem(i,12)*2^5),16);    
    deltan=dec2comp(fix(ephem(i,13)*2^43/gpsPi),16);    %*
    M0=dec2comp(fix(ephem(i,14)*2^31/gpsPi),32);    %*
    Cuc=dec2comp(fix(ephem(i,15)*2^29),16);    %*s
    e=fliplr(dec2binvec(fix(ephem(i,16)*2^33),32));    
    Cus=dec2comp(fix(ephem(i,17)*2^29),16);    %*
    sqrtA=fliplr(dec2binvec(fix(ephem(i,18)*2^19),32));   
    toe=fliplr(dec2binvec(fix(ephem(i,19)/2^4),16));   
    
    Cic=dec2comp(fix(ephem(i,20)*2^29),16);    %*
    OMEGA=dec2comp(fix(ephem(i,21)*2^31/gpsPi),32);    %*
    Cis=dec2comp(fix(ephem(i,22)*2^29),16);    %*
    i0=dec2comp(fix(ephem(i,23)*2^31/gpsPi),32);    %*
    Crc=dec2comp(fix(ephem(i,24)*2^5),16);    %*    
    omega=dec2comp(fix(ephem(i,25)*2^31/gpsPi),32);    %*
    OMEGADOT=dec2comp(fix(ephem(i,26)*2^43/gpsPi),24);    %*
    IDOT=dec2comp(fix(ephem(i,27)*2^43/gpsPi),14);    %*
%subframe4&5 parameters
%     toa=toe(1:8);%��ʱȡ�߰�λ
%     OMEGADOT_s=dec2comp(fix(ephem(i,26)*2^38/gpsPi),16);    %*
%     health_s=[0 0 health];
%     sqrtA_s=sqrtA(1:24);
%     OMEGA_s=OMEGA(1:24);
%     omega_s=omega(1:24);
%     M0_s=M0(1:24);
%     a_f1_s=a_f1(1:11);    %*
%     a_f0_s=a_f0(1:11);    %*    
%     e_s=fliplr(dec2binvec(fix(ephem(i,16)*2^21),16));  
    tow=fix(GPS_sec/6) + 1;   %Z���ܼ��� 9603
    tow1=fliplr(dec2binvec(tow,17));%          00010010110000011
    %�÷���ʱ�̵�ʱ���������
    tow2=fliplr(dec2binvec(tow+1,17));  % 9604 00010010110000100
    tow3=fliplr(dec2binvec(tow+2,17));  % 9605 00010010110000101
    tow4=fliplr(dec2binvec(tow+3,17));  % 9606 00010010110000110
    tow5=fliplr(dec2binvec(tow+4,17));  % 9607 00010010110000111
    tow6=fliplr(dec2binvec(tow+5,17));  % 9608 00010010110001000


%% all 5 sub-frames ================================================
%***********************TLW & HOW
    %WORD1:TLW
    TLW(1:8)=[1 0 0 0 1 0 1 1];%1-8bit,preamble
    TLW(9:22)=[0 0 0 0 0 0 0 0 0 0 0 0 0 0];%9-22 bit,ң����ģ�״̬��ϵ���Ϣ,TLWmessage����ʱȡȫ��
    TLW(23:24)=[0 0];%23-24 bit������λReservedbit1
    D30star=0;
    D29star=0;%ǰһword��ĩ��λĬ��Ϊ0
    TLW(1:30)=parityencode(TLW(1:24),D29star,D30star);

    %WORD2:HOW
    HOW(1:17)=tow1;%1-17bit truncated,TOW
    HOW(18)=0;%ʵ��URA���ڻ��ߺ�����֡1ָʾ��URA��Alertflag
    HOW(19)=1;%if Anti-spoof mode is ON(1),19 bit,ASflag
%    HOW(20:22)Ϊ��֡ʶ���־ 20-22 bit,SubframeID
    HOW(23:24)=[0 0];%23-24 bit,Reservedbit2��Ϊ�˱�֤29��30λ��Ϊ0
        
    subframe=[TLW HOW];

%********************************subframe1ǰ����word������
    subframe1=subframe; %TLW & HOW 
    subframe1(50:52)=de2bi(1,3,'left-msb');%��֡ʶ���־ 20-22 bit,SubframeID; de2biֱ��ת�ɶ�����   
    subframe1a(31:60)=parityencode(subframe1(31:54),subframe1(29),subframe1(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
    if subframe1a(59)~=0 
       subframe1(54)=1;
       if subframe1a(60)==0
           subframe1(53)=1;
       end
    elseif subframe1a(60)~=0
            subframe1(53)=1;
    end

    subframe1(31:60)=parityencode(subframe1(31:54),subframe1(29),subframe1(30));
    
    %WORD3:
    subframe1(61:70)=WN;%1-10bit��WN,GPSweeknumber��after 1980.1.6.00:00
    subframe1(71:72)=CodeL2;%11-12 bit,P(01) C/A(10),L2code
    subframe1(73:76)=URA;%13-16 bit URA,SVaccuracy
    subframe1(77:82)=health;%17-22 bit,SVhealth
    subframe1(83:84)=IODC(1:2);%23-24 bit,   IODC ����λ
    subframe1(61:90)=parityencode(subframe1(61:84),subframe1(59),subframe1(60));
    
    %WORD4
    subframe1(91)=L2P;%L2Pcode data flag
    subframe1(92:114)=zeros(1,23);%reserved
    subframe1(91:120)=parityencode(subframe1(91:114),subframe1(89),subframe1(90));
   
    %WORD5
    subframe1(121:144)=zeros(1,24);%reserved
    subframe1(121:150)=parityencode(subframe1(121:144),subframe1(119),subframe1(120));
    
    %WORD6
    subframe1(151:174)=zeros(1,24);%reserved
    subframe1(151:180)=parityencode(subframe1(151:174),subframe1(149),subframe1(150));
    
    %WORD7
    subframe1(181:196)=zeros(1,16);%reserved
    subframe1(197:204)=tgd;%t_gd
    subframe1(181:210)=parityencode(subframe1(181:204),subframe1(179),subframe1(180));
                                                                        
    %WORD8
    subframe1(211:218)=IODC(3:10);%  IODC �Ͱ�λ
    subframe1(219:234)=toe;% t_oe
    subframe1(211:240)=parityencode(subframe1(211:234),subframe1(209),subframe1(210));
    
    %WORD9
    subframe1(241:248)=a_f2;
    subframe1(249:264)=a_f1;
    subframe1(241:270)=parityencode(subframe1(241:264),subframe1(239),subframe1(240));
    
    %WORD10
    subframe1(271:292)=a_f0;
    subframe1(293:294)=zeros(1,2);%Reservedbit
    subframe1a(271:300)=parityencode(subframe1(271:294),subframe1(269),subframe1(270));
%      subframe1(31:60)=parityencode(subframe1(31:54),subframe1(29),subframe1(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
    if subframe1a(299)~=0 
       subframe1(294)=1;
       if subframe1a(300)==0
           subframe1(293)=1;
       end
    elseif subframe1a(300)~=0
            subframe1(293)=1;
    end
     subframe1(271:300)=parityencode(subframe1(271:294),subframe1(269),subframe1(270));
  
     %*********  ����֡ͬ��һ֡�Ĳ���һ�����������������tow����˲����ظ���һ֡�����ݣ�������������� *******
     
    subframe6=subframe; %TLW & HOW 
    subframe6(31:47)=tow6;
    subframe6(50:52)=de2bi(1,3,'left-msb');%��֡ʶ���־ 20-22 bit,SubframeID; de2biֱ��ת�ɶ�����   
    subframe6a(31:60)=parityencode(subframe6(31:54),subframe6(29),subframe6(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
    if subframe6a(59)~=0 
       subframe6(54)=1;
       if subframe6a(60)==0
           subframe6(53)=1;
       end
    elseif subframe6a(60)~=0
            subframe6(53)=1;
    end

    subframe6(31:60)=parityencode(subframe6(31:54),subframe6(29),subframe6(30));
    
    %WORD3:
    subframe6(61:70)=WN;%1-10bit��WN,GPSweeknumber��after 1980.1.6.00:00
    subframe6(71:72)=CodeL2;%11-12 bit,P(01) C/A(10),L2code
    subframe6(73:76)=URA;%13-16 bit URA,SVaccuracy
    subframe6(77:82)=health;%17-22 bit,SVhealth
    subframe6(83:84)=IODC(1:2);%23-24 bit,   IODC ����λ
    subframe6(61:90)=parityencode(subframe6(61:84),subframe6(59),subframe6(60));
    
    %WORD4
    subframe6(91)=L2P;%L2Pcode data flag
    subframe6(92:114)=zeros(1,23);%reserved
    subframe6(91:120)=parityencode(subframe6(91:114),subframe6(89),subframe6(90));
   
    %WORD5
    subframe6(121:144)=zeros(1,24);%reserved
    subframe6(121:150)=parityencode(subframe6(121:144),subframe6(119),subframe6(120));
    
    %WORD6
    subframe6(151:174)=zeros(1,24);%reserved
    subframe6(151:180)=parityencode(subframe6(151:174),subframe6(149),subframe6(150));
    
    %WORD7
    subframe6(181:196)=zeros(1,16);%reserved
    subframe6(197:204)=tgd;%t_gd
    subframe6(181:210)=parityencode(subframe6(181:204),subframe6(179),subframe6(180));
                                                                        
    %WORD8
    subframe6(211:218)=IODC(3:10);%  IODC �Ͱ�λ
    subframe6(219:234)=toe;% t_oe
    subframe6(211:240)=parityencode(subframe6(211:234),subframe6(209),subframe6(210));
    
    %WORD9
    subframe6(241:248)=a_f2;
    subframe6(249:264)=a_f1;
    subframe6(241:270)=parityencode(subframe6(241:264),subframe6(239),subframe6(240));
    
    %WORD10
    subframe6(271:292)=a_f0;
    subframe6(293:294)=zeros(1,2);%Reservedbit
    subframe6a(271:300)=parityencode(subframe6(271:294),subframe6(269),subframe6(270));
%      subframe6(31:60)=parityencode(subframe6(31:54),subframe6(29),subframe6(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
    if subframe6a(299)~=0 
       subframe6(294)=1;
       if subframe6a(300)==0
           subframe6(293)=1;
       end
    elseif subframe6a(300)~=0
            subframe6(293)=1;
    end
     subframe6(271:300)=parityencode(subframe6(271:294),subframe6(269),subframe6(270)); 
     
     %***************  ����֡���� ******************
     
     
%********************************subframe2ǰ����word������****************
    subframe2=subframe; %TLW & HOW 
    subframe2(31:47)=tow2;
    subframe2(50:52)=de2bi(2,3,'left-msb');%��֡ʶ���־ 20-22 bit,SubframeID;    
    subframe2a(31:60)=parityencode(subframe2(31:54),subframe2(29),subframe2(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
    if subframe2a(59)~=0 
       subframe2(54)=1;
       if subframe2a(60)==0
           subframe2(53)=1;
       end
    elseif subframe2a(60)~=0
            subframe2(53)=1;
    end
    subframe2(31:60)=parityencode(subframe2(31:54),subframe2(29),subframe2(30));
    
    %WORD3
    subframe2(61:68)=IODE;
    subframe2(69:84)=Crs;
    subframe2(61:90)=parityencode(subframe2(61:84),subframe2(59),subframe2(60));
    
    %WORD4
    subframe2(91:106)=deltan;% mean motion difference from computed value;
    subframe2(107:114)=M0(1:8);% MSB 8bit
    subframe2(91:120)=parityencode(subframe2(91:114),subframe2(89),subframe2(90));
    
    %WORD5
    subframe2(121:144)=M0(9:32);% LSB 24bit
    subframe2(121:150)=parityencode(subframe2(121:144),subframe2(119),subframe2(120));
    
    %WORD6
    subframe2(151:166)=Cuc;
    subframe2(167:174)=e(1:8);% MSB 8 bit
    subframe2(151:180)=parityencode(subframe2(151:174),subframe2(149),subframe2(150));
    
    %WORD7
    subframe2(181:204)=e(9:32);% LSB 24bit
    subframe2(181:210)=parityencode(subframe2(181:204),subframe2(179),subframe2(180)); 
    
    %WORD8
    subframe2(211:226)=Cus;
    subframe2(227:234)=sqrtA(1:8);% MSB 8bit
    subframe2(211:240)=parityencode(subframe2(211:234),subframe2(209),subframe2(210));    
    
    %WORD9
    subframe2(241:264)=sqrtA(9:32);% LSB 24bit
    subframe2(241:270)=parityencode(subframe2(241:264),subframe2(239),subframe2(240)); 
    
    %WORD10
    subframe2(271:286)=toe;    
    subframe2(287)=0;%FIT INTERVAL BIT
    subframe2(288:292)=[0 0 0 0 0];%AODO
    subframe2(293:294)=zeros(1,2);%noninformation-bearing bits used for parity computation
    subframe2a(271:300)=parityencode(subframe2(271:294),subframe2(269),subframe2(270)); %Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�

    if subframe2a(299)~=0 
       subframe2(294)=1;
       if subframe2a(300)==0
           subframe2(293)=1;
       end
    elseif subframe2a(300)~=0
            subframe2(293)=1;
    end
      subframe2(271:300)=parityencode(subframe2(271:294),subframe2(269),subframe2(270));   
 %***************************subframe3   
    subframe3=subframe; %TLW & HOW 
    subframe3(31:47)=tow3;
    subframe3(50:52)=de2bi(3,3,'left-msb');%��֡ʶ���־ 20-22 bit,SubframeID;    
    subframe3a(31:60)=parityencode(subframe3(31:54),subframe3(29),subframe3(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
    if subframe3a(59)~=0 
       subframe3(54)=1;
       if subframe3a(60)==0
           subframe3(53)=1;
       end
    elseif subframe3a(60)~=0
            subframe3(53)=1;
    end
    subframe3(31:60)=parityencode(subframe3(31:54),subframe3(29),subframe3(30));
    
    %WORD3
    subframe3(61:76)=Cic;
    subframe3(77:84)=OMEGA(1:8);% MSB 8bit;
    subframe3(61:90)=parityencode(subframe3(61:84),subframe3(59),subframe3(60));
    
    %WORD4
    subframe3(91:114)=OMEGA(9:32);% LSB 24bit
    subframe3(91:120)=parityencode(subframe3(91:114),subframe3(89),subframe3(90));
    
    %WORD5
    subframe3(121:136)=Cis;
    subframe3(137:144)=i0(1:8);% MSB 8bit
    subframe3(121:150)=parityencode(subframe3(121:144),subframe3(119),subframe3(120));
    
    %WORD6
    subframe3(151:174)=i0(9:32);% LSB 24 bit
    subframe3(151:180)=parityencode(subframe3(151:174),subframe3(149),subframe3(150));
    
    %WORD7
    subframe3(181:196)=Crc;
    subframe3(197:204)=omega(1:8); %MSB 8bit
    subframe3(181:210)=parityencode(subframe3(181:204),subframe3(179),subframe3(180)); 
    
    %WORD8
    subframe3(211:234)=omega(9:32);% LSB 24bit
    subframe3(211:240)=parityencode(subframe3(211:234),subframe3(209),subframe3(210));    
    
    %WORD9
    subframe3(241:264)=OMEGADOT;% 24bit
    subframe3(241:270)=parityencode(subframe3(241:264),subframe3(239),subframe3(240)); 
    
    %WORD10
    subframe3(271:278)=IODE;
    subframe3(279:292)=IDOT;
    subframe3(293:294)=zeros(1,2);%noninformation-bearing bits used for parity computation
    subframe3a(271:300)=parityencode(subframe3(271:294),subframe3(269),subframe3(270)); 
 %Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�

    if subframe3a(299)~=0 
       subframe3(294)=1;
       if subframe3a(300)==0
           subframe3(293)=1;
       end
    elseif subframe3a(300)~=0
            subframe3(293)=1;
    end
     subframe3(271:300)=parityencode(subframe3(271:294),subframe3(269),subframe3(270)); 
     
   subframe123=[subframe1 subframe2 subframe3]; 
   

%********************************subframe4ǰ����word������
    subframe4=subframe; %TLW & HOW 
    subframe4(31:47)=tow4;
    subframe4(50:52)=de2bi(4,3,'left-msb');%��֡ʶ���־ 20-22 bit,SubframeID;    
    subframe4a(31:60)=parityencode(subframe4(31:54),subframe4(29),subframe4(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
    if subframe4a(59)~=0 
       subframe4(54)=1;
       if subframe4a(60)==0
           subframe4(53)=1;
       end
    elseif subframe4a(60)~=0
            subframe4(53)=1;
    end
    subframe4(31:60)=parityencode(subframe4(31:54),subframe4(29),subframe4(30));
%********************************subframe5ǰ����word������
    subframe5=subframe; %TLW & HOW 
    subframe5(31:47)=tow5;    
    subframe5(50:52)=de2bi(5,3,'left-msb');%��֡ʶ���־ 20-22 bit,SubframeID;    
    subframe5a(31:60)=parityencode(subframe5(31:54),subframe5(29),subframe5(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
    if subframe5a(59)~=0 
       subframe5(54)=1;
       if subframe5a(60)==0
           subframe5(53)=1;
       end
    elseif subframe5a(60)~=0
            subframe5(53)=1;
    end
    subframe5(31:60)=parityencode(subframe5(31:54),subframe5(29),subframe5(30));
    
%********************subfreame4 TYPE 1=>1,6,11,16,21 or 12,19,20,22,23,24****
        subframe4(61:62)=[1 0];
        subframe4(63:68)=de2bi(57,6,'left-msb');
        
        subframe4(69:84)=zeros(1,16);
        subframe4(61:90)=parityencode(subframe4(61:84),subframe4(59),subframe4(60));
        
        subframe4(91:114)=zeros(1,24);%Reserved
        subframe4(91:120)=parityencode(subframe4(91:114),subframe4(89),subframe4(90));
        
        subframe4(121:144)=zeros(1,24);%Reserved
        subframe4(121:150)=parityencode(subframe4(121:144),subframe4(119),subframe4(120));
        
        subframe4(151:174)=zeros(1,24);%Reserved
        subframe4(151:180)=parityencode(subframe4(151:174),subframe4(149),subframe4(150));
        
        subframe4(181:204)=zeros(1,24);%Reserved
        subframe4(181:210)=parityencode(subframe4(181:204),subframe4(179),subframe4(180));
        
        subframe4(211:234)=zeros(1,24);%Reserved
        subframe4(211:240)=parityencode(subframe4(211:234),subframe4(209),subframe4(210));
        
        subframe4(241:264)=zeros(1,24);%Reserved
        subframe4(241:270)=parityencode(subframe4(241:264),subframe4(239),subframe4(240));
        
         
        subframe4(271:292)=zeros(1,22);
        subframe4(293:294)=zeros(1,2);%Reserved
        subframe4a(271:300)=parityencode(subframe4(271:294),subframe4(269),subframe4(270)); %Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
        
    if subframe4a(299)~=0 
       subframe4(294)=1;
       if subframe4a(300)==0
           subframe4(293)=1;
       end
    elseif subframe4a(300)~=0
            subframe4(293)=1;
    end
     subframe4(271:300)=parityencode(subframe4(271:294),subframe4(269),subframe4(270));
      
%**************************************subframe 5 Page1     
        j=find(ephem(:,1)==1);%��һҳ�ҵ���һ�����ǵ���������

%subframe4&5 parameters
    toe_s=fliplr(dec2binvec(fix(ephem(j,19)/2^4),16));
    deltan=dec2comp(fix(ephem(j,13)*2^43/gpsPi),16);    %*
    toa=toe_s(1:8);%��ʱȡ�߰�λ
    OMEGADOT_s=dec2comp(fix(ephem(j,26)*2^38/gpsPi),16);    %*
    health=fliplr(dec2binvec(ephem(j,32),6));
    health_s=[0 0 health];
    sqrtA=fliplr(dec2binvec(fix(ephem(j,18)*2^19),32));   
    sqrtA_s=sqrtA(1:24);
    OMEGA=dec2comp(fix(ephem(j,21)*2^31/gpsPi),32);    %*
    OMEGA_s=OMEGA(1:24);
    omega=dec2comp(fix(ephem(j,25)*2^31/gpsPi),32);    %*
    omega_s=omega(1:24);
    M0=dec2comp(fix(ephem(j,14)*2^31/gpsPi),32);    %*
    M0_s=M0(1:24);
    a_f2=dec2comp(fix(ephem(j,10)*2^55),8);    %*��ͬ��
    a_f1=dec2comp(fix(ephem(j,9)*2^43),16);    %*
    a_f0=dec2comp(fix(ephem(j,8)*2^31),22);    %*
    a_f1_s=a_f1(1:11);    %*
    a_f0_s=a_f0(1:11);    %*    
    e_s=fliplr(dec2binvec(fix(ephem(j,16)*2^21),16));          
        
        subframe5(61:62)=[0 1];
        subframe5(63:68)=de2bi(1,6,'left-msb');    
        subframe5(69:84)=e_s;
        subframe5(61:90)=parityencode(subframe5(61:84),subframe5(59),subframe5(60));
        subframe5(91:98)=toa;
        subframe5(99:114)=deltan;%��ʵӦ��Ϊdela i,��ʱû���ҵ���Ӧ��Ԫ�� 
        subframe5(91:120)=parityencode(subframe5(91:114),subframe5(89),subframe5(90));
        subframe5(121:136)=OMEGADOT_s;
        subframe5(137:144)=health_s;
        subframe5(121:150)=parityencode(subframe5(121:144),subframe5(119),subframe5(120));
        subframe5(151:174)=sqrtA_s;
        subframe5(151:180)=parityencode(subframe5(151:174),subframe5(149),subframe5(150));
        subframe5(181:204)=OMEGA_s;
        subframe5(181:210)=parityencode(subframe5(181:204),subframe5(179),subframe5(180));
        subframe5(211:234)=omega_s;
        subframe5(211:240)=parityencode(subframe5(211:234),subframe5(209),subframe5(210));
        subframe5(241:264)=M0_s;
        subframe5(241:270)=parityencode(subframe5(241:264),subframe5(239),subframe5(240));
        subframe5(271:278)=a_f0_s(1:8);
        subframe5(279:289)=a_f1_s;
        subframe5(290:292)=a_f0_s(9:11);        
        subframe5(293:294)=[0 0];
        subframe5a(271:300)=parityencode(subframe5(271:294),subframe5(269),subframe5(270));
%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
    if subframe5a(299)~=0 
       subframe5(294)=1;
       if subframe5a(300)==0
           subframe5(293)=1;
       end
    elseif subframe5a(300)~=0
            subframe5(293)=1;
    end
     subframe5(271:300)=parityencode(subframe5(271:294),subframe5(269),subframe5(270));
%********************************

%     subframe6=subframe; %TLW & HOW 
%     subframe6(31:47)=tow6;
%     subframe6(50:52)=de2bi(1,3,'left-msb');%��֡ʶ���־ 20-22 bit,SubframeID; de2biֱ��ת�ɶ�����   
%     subframe6a(31:60)=parityencode(subframe6(31:54),subframe6(29),subframe6(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
%     if subframe6a(59)~=0 
%        subframe6(54)=1;
%        if subframe6a(60)==0
%            subframe6(53)=1;
%        end
%     elseif subframe6a(60)~=0
%             subframe6(53)=1;
%     end
% 
%     subframe6(31:60)=parityencode(subframe6(31:54),subframe6(29),subframe6(30));
%     
%     %WORD3:
%     subframe6(61:70)=WN;%1-10bit��WN,GPSweeknumber��after 1980.1.6.00:00
%     subframe6(71:72)=CodeL2;%11-12 bit,P(01) C/A(10),L2code
%     subframe6(73:76)=URA;%13-16 bit URA,SVaccuracy
%     subframe6(77:82)=health;%17-22 bit,SVhealth
%     subframe6(83:84)=IODC(1:2);%23-24 bit,   IODC ����λ
%     subframe6(61:90)=parityencode(subframe6(61:84),subframe6(59),subframe6(60));
%     
%     %WORD4
%     subframe6(91)=L2P;%L2Pcode data flag
%     subframe6(92:114)=zeros(1,23);%reserved
%     subframe6(91:120)=parityencode(subframe6(91:114),subframe6(89),subframe6(90));
%    
%     %WORD5
%     subframe6(121:144)=zeros(1,24);%reserved
%     subframe6(121:150)=parityencode(subframe6(121:144),subframe6(119),subframe6(120));
%     
%     %WORD6
%     subframe6(151:174)=zeros(1,24);%reserved
%     subframe6(151:180)=parityencode(subframe6(151:174),subframe6(149),subframe6(150));
%     
%     %WORD7
%     subframe6(181:196)=zeros(1,16);%reserved
%     subframe6(197:204)=tgd;%t_gd
%     subframe6(181:210)=parityencode(subframe6(181:204),subframe6(179),subframe6(180));
%                                                                         
%     %WORD8
%     subframe6(211:218)=IODC(3:10);%  IODC �Ͱ�λ
%     subframe6(219:234)=toe;% t_oe
%     subframe6(211:240)=parityencode(subframe6(211:234),subframe6(209),subframe6(210));
%     
%     %WORD9
%     subframe6(241:248)=a_f2;
%     subframe6(249:264)=a_f1;
%     subframe6(241:270)=parityencode(subframe6(241:264),subframe6(239),subframe6(240));
%     
%     %WORD10
%     subframe6(271:292)=a_f0;
%     subframe6(293:294)=zeros(1,2);%Reservedbit
%     subframe6a(271:300)=parityencode(subframe6(271:294),subframe6(269),subframe6(270));
% %      subframe6(31:60)=parityencode(subframe6(31:54),subframe6(29),subframe6(30));%Ϊ�˱�֤29��30λ��Ϊ0,���ж������λ���޸�
%     if subframe6a(299)~=0 
%        subframe6(294)=1;
%        if subframe6a(300)==0
%            subframe6(293)=1;
%        end
%     elseif subframe6a(300)~=0
%             subframe6(293)=1;
%     end
%      subframe6(271:300)=parityencode(subframe6(271:294),subframe6(269),subframe6(270));    
%********************************    
subframep1=[subframe123 subframe4 subframe5 subframe6];
return;              