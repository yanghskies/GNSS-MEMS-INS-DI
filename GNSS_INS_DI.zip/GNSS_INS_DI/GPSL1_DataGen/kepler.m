function ek = kepler(mk,e)

% ek = kepler(mk,e) 
% Utility function called by svpos.m
%    kepler - Solves Kepler's equation for ek through iteration. 
%                                                                
% Inputs: mk: mean anomaly (rad),
%         e:  eccentricity,
% Outputs: ek: eccentric anomaly,
%
% NOTE: mk and e may be a vectors of the same dimensions, or one may be a scalar
%       the output is a vector of the same dimensions as the input vector
  
%Check inputs size
if min(size(mk))>1
  error('mk must be a vector or a scalar, not a matrix')
end
if min(size(e))>1
  error('e must be a vector or a scalar, not a matrix')
end
if length(mk)>1 & length(e)>1 & any(size(mk)~=size(e)) %both are vectors, they must have the same dimensions
  error('If mk and e are both vectors they must have the same dimensions')
end

err = 1;

ek=mk;
while any(abs(err) > 1.0e-8)
  err = ek - mk - (e.*sin(ek));
  ek = ek - err;
end;
