function total = julian(year,month,day)

% total=julian(year,month,day) 
% 
% Calculate the modified Julian date.
%   On 1972,1,1 the MJD is  41317
%   On 1972,1,1 the Julian Date is 2441317.5
%   To compute the Julian Date from this routine add 2400000.5
% 
% All inputs may be vectors of equal length, the output
% is a corresponding vector.
% 
% Inputs:  year: 1993 (enter 4 digit year)
%          month: scalar (1-12); January=1, December=12
%          day: day of month
% 
%          Valid range: (1972,1,1) <= date < (2100,1,1)
% 
% Outputs: total: number of days since
% 
% Example:
%   � total=julian(2000,10,13)
%   total =
%          51830
%   �  

[m1,n1] = size(year(:));
[m2,n2] = size(month(:));
[m3,n3] = size(day(:));

if any([m1,m2,m3,n1,n2,n3]==0)
  error('empty input, inputs must be vectors or scalars')
end

if any( ([m1,m2]-m3)~=0 )
  error('inputs must all be vectors of the same length')
end

if any( [n1,n2,n3]~=1 )
  error('inputs must be vectors')
end

%check that year is in valid range
if ( any(year<1972) | any(year>2099) )
  error('year must have values in the range: [1972:2099]')
end

% get all the days for previous years */
y = year(:)-1972;
total = y*365;

% add one day for each leap year, the number of leap years from 1980/1/1 to year/1/1 is given by
% ceil( (year-1972)/4)
total = total + ceil(y/4);
% now we have number of days since Jan 1,1972 to Jan 1,year */

daysgoneby = [0,31,59,90,120,151,181,212,243,273,304,334];
for m = 1:12 % for each possible month
  I = find(month==m); % index into month == m
  
  if any(I)
    total(I) = total(I) + daysgoneby(m);
  end
end
% now we have number of days since Jan 1,1972 to month 1,year */

total = total + day(:);
% now we have number of days since Jan 1,1972 to month day,year */

% if the current year is a leap year and month is after February */
leapyears = isleapyear(year);
I = find((leapyears==1) & (month>2));
%I = find( (rem(year,4))==0 & month>2 );
if any(I)
  total(I) = total(I) + 1;
end

total = total + 41316;   %MJD on 1/1/72 is 41317