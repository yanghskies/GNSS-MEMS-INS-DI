function [x,y,z] = lla2ecef(lat,lon,alt)

% [x,y,z] = lla2ecef(lat,lon,alt)
%  ��������꾭�ȣ�γ�ȣ�����ת��ΪECEF����
%  inputs: 
%     lat, lon: ���ȣ�γ��(degrees)
%     alt: ����(meters)
%  outputs: 
%     [x y z]:ECEF����
%

	if (lat < -90.0) || (lat > +90.0) || (lon < -180.0) || (lon > +360.0)
		error('WGS lat or WGS lon out of range');
    end
    
    A_EARTH = 6378137;%ellipsoid's semi-major axis
	flattening = 1/298.257223563;
	NAV_E2 = (2-flattening)*flattening; % ellipsoid's eccentricity^2
	D2R = pi/180;

    clat = cos(lat*D2R);
    clon = cos(lon*D2R);
    slat = sin(lat*D2R);
    slon = sin(lon*D2R);
    
	r0= A_EARTH/sqrt(1 - NAV_E2*slat*slat);
    x = (alt + r0) .* clat .* clon;                            % x-coord
    y = (alt + r0) .* clat .* slon;                            % y-coord
    z = (alt + r0 .* (1.0 - NAV_E2)) .* slat;                  % z-coord

return
