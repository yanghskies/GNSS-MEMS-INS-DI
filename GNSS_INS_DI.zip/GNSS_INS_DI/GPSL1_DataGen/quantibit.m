function result = quantibit(data, N)
% NС�ڵ���8
split = -(2^N-2)/(2^N-1):2/(2^N-1):(2^N-2)/(2^N-1);
split = split * 2^7;
sam = -1:2/(2^N-1):1;
sam = sam * 2^7;
% result = zeros(1,length(data));
result = sam(1) * (data < split(1));
for k = 1:length(split)-1
    result = result + sam(k+1) * ( (data >=split(k)) & (data<split(k+1)) );
end
result = result + sam(end) * (data >= split(end));
result = int8(result);
