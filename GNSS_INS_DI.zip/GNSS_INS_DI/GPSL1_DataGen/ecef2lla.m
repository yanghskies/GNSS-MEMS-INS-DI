function [lat,lon,alt] = ecef2lla(x,y,z)
% [lat,lon,alt] = ecef2lla(x,y,z)
%��ECEF����ת��Ϊ������꣬����γ�ȣ�����
% Inputs: 
%     [x y z]:ECEF����
%���������Ϊ3x1ʱ�����
% Outputs: 
%     lat, lon: ���ȣ�γ��(degrees)
%     alt: ����(meters)

if nargin==1
  if length(x(1,:))~=3
    error('A single input must have three columns');
  end
  temp = x;
  x=temp(:,1);
  y=temp(:,2);
  z=temp(:,3);
end   

EARTHECCEN2 = 6.694379990141317e-3;
EARTHSEMIMAJOR = 6378137;
onemes = 1-EARTHECCEN2;
WEEKSEC = 604800;        
R2D = 180/pi;
lat_eps=eps;% ���Էֱ����С����


% execute only if x and y positions are not both zero
% if x ~= 0.0 & y ~= 0.0
nozeros=1;
for i=1:length(x)
  if (x(i)==0 && y(i)==0), 
      nozeros=0;
  end,
end,
if nozeros
  %following algorithm from Hoffman-Wellenhof, Lichtenegger & Collins "GPS Theory & Practice"
  a = EARTHSEMIMAJOR;
  a2 = a^2;
  b2 = a2*onemes;      
  b = sqrt(b2);
  e2 = EARTHECCEN2;
  ep2 = (a2-b2)/b2;
  p=sqrt(x.^2 + y.^2);
  % two sides and hypotenuse of right-angle-triangle with one angle = theta
  s1 = z*a;
  s2 = p*b;   
  h = sqrt(s1.^2 + s2.^2);
  sin_theta = s1./h;
  cos_theta = s2./h;
  theta = atan(s1./s2);
  
  % two sides and hypotenuse of right-angle-triangle with one angle = lat
  % ֱ�������ε������ߺ�б�ߣ�һ���Ƕ�=γ��
  s1 = z+ep2*b*(sin_theta.^3);
  s2 = p-a*e2.*(cos_theta.^3);
  h = sqrt(s1.^2 + s2.^2);
  
  tan_lat = s1./s2;
  sin_lat = s1./h;
  cos_lat = s2./h;
  lat = atan(tan_lat);
  lat = lat*R2D;
  
  N = a2*((a2*(cos_lat.^2) + b2*(sin_lat.^2)).^(-0.5));
  alt = p./cos_lat - N;
  
  lon = atan2(y,x);
  lon = rem(lon,2*pi)*R2D;
  if (lon>180)
    lon = lon-360;
  end
end
