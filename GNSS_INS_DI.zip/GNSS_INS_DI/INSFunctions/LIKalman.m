function [LI,I] = LIKalman(LI,I,X)

global parameter;

        F = zeros(17,17);
        F(2,3) = I.Wie(1)+I.Wep(1);
        F(1,3) = -(I.Wie(2)+I.Wep(2));
        F(1,2) = I.Wie(3)+I.Wep(3);
        F(2,1) = -(I.Wie(3)+I.Wep(3));
        F(3,1) = I.Wie(2)+I.Wep(2);
        F(3,2) = -(I.Wie(1)+I.Wep(1));
        
        F(1,5) = 1/(I.nRe+LI.height);
        F(2,4) = -1/(I.nRn+LI.height);
        F(3,5) = -tan(LI.latitude)/(I.nRe+LI.height);
        
        F(1,7) = -parameter.We*sin(LI.latitude);
        F(3,7) = -parameter.We*cos(LI.latitude)-LI.vn(2)/((I.nRe+LI.height)*cos(LI.latitude)*cos(LI.latitude));
        
        F(1:3,10:12) = -I.Cnb;
        
        F(5,3) = -I.dv_f_n(1)/I.dt;
        F(4,3) = I.dv_f_n(2)/I.dt;
        F(4,2) = -I.dv_f_n(3)/I.dt;
        F(5,1) = I.dv_f_n(3)/I.dt;
        F(6,1) = -I.dv_f_n(2)/I.dt;
        F(6,2) = I.dv_f_n(1)/I.dt;
        
        F(4,4) = LI.vn(3)/(I.nRn+LI.height);
        F(4,5) = -2*(parameter.We*sin(LI.latitude)+LI.vn(2)*tan(LI.latitude)/(I.nRe+LI.height));
        F(4,6) = LI.vn(1)/(I.nRn+LI.height);
        F(5,4) = 2*parameter.We*sin(LI.latitude)+LI.vn(2)*tan(LI.latitude)/(I.nRe+LI.height);
        F(5,5) = LI.vn(1)*tan(LI.latitude)/(I.nRe+LI.height)+LI.vn(3)/(I.nRe+LI.height);
        F(5,6) = 2*parameter.We*cos(LI.latitude)+LI.vn(2)/(I.nRe+LI.height);
        F(6,4) = -2*LI.vn(1)/(I.nRn+LI.height);
        F(6,5) = -2*(parameter.We*cos(LI.latitude)+LI.vn(2)/(I.nRe+LI.height));
        
        F(4,7) = -(2*parameter.We*cos(LI.latitude)+LI.vn(2)/((I.nRe+LI.height)*cos(LI.latitude)*cos(LI.latitude)))*LI.vn(2);
        F(5,7) = (2*parameter.We*cos(LI.latitude)+LI.vn(2)/((I.nRe+LI.height)*cos(LI.latitude)*cos(LI.latitude)))*LI.vn(1)-2*parameter.We*LI.vn(3)*sin(LI.latitude);
        F(6,7) = 2*LI.vn(2)*parameter.We*sin(LI.latitude);
        F(6,9) = -2*I.gn(3)/parameter.Re;
        
        F(4:6,13:15) = I.Cnb;
        
        F(7,4) = 1/(I.nRn+LI.height);
        F(8,5) = 1/((I.nRe+LI.height)*cos(LI.latitude));
        F(9,6) = -1;
        
        F(8,7) = LI.vn(2)*tan(LI.latitude)/((I.nRe+LI.height)*cos(LI.latitude));
        F(16,17) = 1;
        
        LI.FI = F*LI.dt + eye(17,17);
        
%         LI.R = zeros(length(X.activeChnList),length(X.activeChnList));
%         for ii=1:length(X.activeChnList)
%             lx=LI.X-X.satPositions(1,ii);
%             ly=LI.Y-X.satPositions(2,ii);
%             lz=LI.Z-X.satPositions(3,ii);
%             norm_a=sqrt(lx*lx+ly*ly+lz*lz);
%             a=[lx;ly;lz]/norm_a;
%             H(ii,:)=[0,0,0,0,0,0,a(1),a(2),a(3),0,0,0,0,0,0,+1,0];
%             Z(ii,1) = -((X.rawP(ii)-LI.savedx(16))-norm_a);
%             %����Ӧ�㷨
%             LI.R(ii,ii) = 100;
%         end
%         Cxen=zeros(17,17);
%         Cxen(1:3,1:3)=I.Cne';
%         Cxen(4:6,4:6)=I.Cne';
%         Ntemp=parameter.Re/sqrt(1-parameter.e*(2-parameter.e)*sin(LI.latitude)*sin(LI.latitude));
%         Cxen(7:9,7:9)=[-(Ntemp+LI.height)*cos(LI.longitude)*sin(LI.latitude) -(Ntemp+LI.height)*cos(LI.latitude)*sin(LI.longitude) cos(LI.latitude)*cos(LI.longitude);
%             -(Ntemp+LI.height)*sin(LI.longitude)*sin(LI.latitude) (Ntemp+LI.height)*cos(LI.latitude)*cos(LI.longitude) cos(LI.latitude)*sin(LI.longitude);
%             ((1-parameter.e)^2*Ntemp+LI.height)*cos(LI.latitude) 0 sin(LI.latitude)];
%         Cxen(10:17,10:17)=eye(8,8);
%         LI.H = H*Cxen;    

%         LI.R = zeros(2*length(X.activeChnList),2*length(X.activeChnList));
        %  ״̬���� ��̬ �ٶ� λ�� ������ ���ٶȼ� ��ƫ ��Ư
        %  ��������λ�� �ٶ�
        for ii=1:length(X.activeChnList)
            lx=LI.X-X.satPositions(1,ii);
            ly=LI.Y-X.satPositions(2,ii);
            lz=LI.Z-X.satPositions(3,ii);
            norm_a=sqrt(lx*lx+ly*ly+lz*lz);
            a=[lx;ly;lz]/norm_a;
            H(ii,:)=[0,0,0,0,0,0,a(1),a(2),a(3),0,0,0,0,0,0,1,0];
            H(ii+length(X.activeChnList),:)=[0,0,0,a(1),a(2),a(3),0,0,0,0,0,0,0,0,0,0,1];
            fprintf('ii=%d \n',ii);
            % ״̬��α������α�������
            Z(ii,1) = -((X.rawP(ii)-LI.savedx(16))-norm_a);
            Z(ii+length(X.activeChnList),1) = ((I.Cne'*LI.vn - X.satPositions(4:6,ii))'*(+a)-(X.rawdP(ii)-LI.savedx(17)));
%             %����Ӧ�㷨
%             LI.R(ii,ii) = 10;
%             LI.R(ii+length(X.activeChnList),ii+length(X.activeChnList)) = 0.2^2;
        end
        Cxen=zeros(17,17);
        Cxen(1:3,1:3)=I.Cne';
        Cxen(4:6,4:6)=I.Cne';
        Ntemp=parameter.Re/sqrt(1-parameter.e*(2-parameter.e)*sin(LI.latitude)*sin(LI.latitude));
        Cxen(7:9,7:9)=[-(Ntemp+LI.height)*cos(LI.longitude)*sin(LI.latitude) -(Ntemp+LI.height)*cos(LI.latitude)*sin(LI.longitude) cos(LI.latitude)*cos(LI.longitude);
            -(Ntemp+LI.height)*sin(LI.longitude)*sin(LI.latitude) (Ntemp+LI.height)*cos(LI.latitude)*cos(LI.longitude) cos(LI.latitude)*sin(LI.longitude);
            ((1-parameter.e)^2*Ntemp+LI.height)*cos(LI.latitude) 0 sin(LI.latitude)];
        Cxen(10:17,10:17)=eye(8,8);
        LI.H = H*Cxen; 
        
%         LI.R = zeros(2*length(X.activeChnList),2*length(X.activeChnList));
%         for ii=1:length(X.activeChnList)
%             lx=X.satPositions(1,ii)-LI.X;
%             ly=X.satPositions(2,ii)-LI.Y;
%             lz=X.satPositions(3,ii)-LI.Z;
%             norm_a=sqrt(lx*lx+ly*ly+lz*lz);
%             a=[lx;ly;lz]/norm_a;
%             H(ii,:)=[0,0,0,0,0,0,-a(1),-a(2),-a(3),0,0,0,0,0,0,+1,0];
%             H(ii+length(X.activeChnList),:)=[0,0,0,-a(1),-a(2),-a(3),0,0,0,0,0,0,0,0,0,0,1];
%             Z(ii,1) = -((X.rawP(ii)-LI.savedx(16))-norm_a);
%             Z(ii+length(X.activeChnList),1) = ((X.satPositions(4:6,ii) - I.Cne'*LI.vn)'*(+a)-(X.rawdP(ii)-LI.savedx(17)));
%             %����Ӧ�㷨
%             LI.R(ii,ii) = 10;
%             LI.R(ii+length(X.activeChnList),ii+length(X.activeChnList)) = 0.5^2;
%         end
        
%         LI.R = zeros(length(X.activeChnList),length(X.activeChnList));
%         for ii=1:length(X.activeChnList)
%             lx=X.satPositions(1,ii)-LI.X;
%             ly=X.satPositions(2,ii)-LI.Y;
%             lz=X.satPositions(3,ii)-LI.Z;
%             norm_a=sqrt(lx*lx+ly*ly+lz*lz);
%             a=[lx;ly;lz]/norm_a;
%             H(ii,:)=[0,0,0,0,0,0,-a(1),-a(2),-a(3),0,0,0,0,0,0,1,0];
%             Z(ii,1) = -((X.rawP(ii)-LI.savedx(16))-norm_a);
%             %����Ӧ�㷨
%             LI.R(ii,ii) = 100;
%         end

        %״̬���ӵ�������ϵ��ECEF����ϵ��ת������
%         Cxen=zeros(17,17);
%         Cxen(1:3,1:3)=I.Cne';
%         Cxen(4:6,4:6)=I.Cne';
%         Cxen(7:9,7:9)=I.Cne'*diag([parameter.Re,parameter.Re*cos(LI.latitude),1]);
%         Cxen(10:17,10:17)=eye(8,8);
%         LI.H = H*Cxen;
        
        Xkk_1 = LI.FI*LI.dx;
        Xkk_1 = Xkk_1 - LI.Tdx;
        Pkk_1 = LI.FI*LI.P*LI.FI'+LI.Q;
        LI.K = Pkk_1*LI.H'*inv(LI.H*Pkk_1*LI.H'+ LI.R);%�Ĺ�
        LI.P = (eye(17,17)-LI.K*LI.H)*Pkk_1;
        LI.dx = Xkk_1 + LI.K*(Z-LI.H*Xkk_1);
%         fprintf('Xkk_1��m = %d; n = %d\n',size(Xkk_1,1),size(Xkk_1,2));
%         fprintf('LI.FI��m = %d; n = %d\n',size(LI.FI,1),size(LI.FI,2));
%         fprintf('LI.P��m = %d; n = %d\n',size(LI.P,1),size(LI.P,2));
%         fprintf('LI.H��m = %d; n = %d\n',size(LI.H,1),size(LI.H,2));
%         fprintf('Pkk_1��m = %d; n = %d\n',size(Pkk_1,1),size(Pkk_1,2));
%         fprintf('LI.R��m = %d; n = %d\n',size(LI.R,1),size(LI.R,2));
        % LI.dx = -LI.dx;
        % update
        I.Qnb = qmul(rv2q(LI.dx(1:3,:)),I.Qnb);
        I.Qnb=I.Qnb/norm(I.Qnb);%��Ԫ����һ��
        I.Cnb=Q2DCM(I.Qnb);	
        LI.vn = LI.vn - LI.dx(4:6);
        LI.vnError = LI.dx(4:6);
        LI.latitude = LI.latitude - LI.dx(7);
        LI.longitude = LI.longitude - LI.dx(8);
        LI.height = LI.height - LI.dx(9);
        LI.Gyro_Offset = LI.Gyro_Offset + LI.dx(10:12);
        LI.Acce_Offset = LI.Acce_Offset + LI.dx(13:15);
        I.Cne=[-sin(LI.latitude)*cos(LI.longitude), -sin(LI.latitude)*sin(LI.longitude),  cos(LI.latitude);
            -sin(LI.longitude),                cos(LI.longitude),                 0;
            -cos(LI.latitude)*cos(LI.longitude),  -cos(LI.latitude)*sin(LI.longitude),  -sin(LI.latitude)];
        %save data
        LI.save_dx(:,X.currMeasNr) = LI.dx;
        LI.save_Gyro_Offset(:,X.currMeasNr) =LI.Gyro_Offset;
        LI.save_Acce_Offset(:,X.currMeasNr) =LI.Acce_Offset;
        LI.save_Z(:,X.currMeasNr) = Z;
        
        LI.savedx = LI.savedx - LI.dx;
        LI.dx  = zeros(17,1);
        LI.Tdx = zeros(17,1);
%      LI.Tdx = LI.dx;
        