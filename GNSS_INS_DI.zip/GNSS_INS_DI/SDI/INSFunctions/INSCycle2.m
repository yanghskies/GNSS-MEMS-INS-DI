function [LI,I] = INSCycle2(LI,I,X,MMQ)

global S;

    f1 = MMQ(1:3,2*X.currINS)   + I.oaSet - (LI.Acce_Offset-LI.Tdx(13:15)*I.dt);
    f2 = MMQ(1:3,2*X.currINS+1) + I.oaSet - (LI.Acce_Offset-LI.Tdx(13:15)*I.dt);
    w1 = MMQ(4:6,2*X.currINS)   + I.ogSet - (LI.Gyro_Offset-LI.Tdx(10:12)*I.dt);
    w2 = MMQ(4:6,2*X.currINS+1) + I.ogSet - (LI.Gyro_Offset-LI.Tdx(10:12)*I.dt);
   
   %% ��̬����
   %%  ˫��������
    drg1=w1*I.ts;drg2=w2*I.ts;dva1=f1*I.ts;dva2=f2*I.ts;drg=drg1+drg2;dva=dva1+dva2;
    rvet=drg+2/3*cross(drg1,drg2);
    dvb=dva+0.5*cross(drg,dva)+2/3*(cross(dva1,drg2)+cross(drg1,dva2));
    Vmid=LI.vn+I.Dvn;
    Vpre = LI.vn;
    I.Wep = [Vmid(2)/(I.nRe+LI.height);-Vmid(1)/(I.nRn+LI.height);-Vmid(2)*tan(LI.latitude)/(I.nRe+LI.height)];
    zeta=(I.Wie+I.Wep-LI.Tdx(1:3))*I.dt;
    Cn=[1,zeta(3)*0.5,-zeta(2)*0.5;
        -zeta(3)*0.5,1,zeta(1)*0.5;
        zeta(2)*0.5,-zeta(1)*0.5,1];
    %% �ٶȸ���
    I.dv_f_n=Cn*I.Cnb*dvb;
    dv_g_cor=(I.gn-cross(2*I.Wie+I.Wep,Vmid))*I.dt;
    I.Dvn=I.dv_f_n+dv_g_cor;
    LI.vn=LI.vn+I.Dvn-LI.Tdx(4:6)*I.dt;
    %% λ�ø���
    Vmid=0.5*(LI.vn+Vpre);
    I.Wep = [Vmid(2)/(I.nRe+LI.height);-Vmid(1)/(I.nRn+LI.height);-Vmid(2)*tan(LI.latitude)/(I.nRe+LI.height)];
%     Cne_cor=[1,I.Wep(3)*I.dt,-I.Wep(2)*I.dt;
%              -I.Wep(3)*I.dt,1,I.Wep(1)*I.dt;
%              I.Wep(2)*I.dt,-I.Wep(1)*I.dt,1];
%     I.Cne=Cne_cor*I.Cne;
    LI.latitude=LI.latitude+Vmid(1)/(I.nRn+LI.height)*I.dt - LI.Tdx(7)*I.dt;
    LI.longitude=LI.longitude+Vmid(2)/((I.nRe+LI.height)*cos(LI.latitude))*I.dt - LI.Tdx(8)*I.dt;
    LI.height=LI.height-Vmid(3)*I.dt - LI.Tdx(9)*I.dt;
    I.Cne=[-sin(LI.latitude)*cos(LI.longitude), -sin(LI.latitude)*sin(LI.longitude),  cos(LI.latitude);
        -sin(LI.longitude),                cos(LI.longitude),                 0;
        -cos(LI.latitude)*cos(LI.longitude),  -cos(LI.latitude)*sin(LI.longitude),  -sin(LI.latitude)];
%     [nRn,nRe,gn,Wie,Wep] = EarthCalc(LI.latitude,LI.height,LI.vn);
    Ntemp=S.Re/sqrt(1-S.e*(2-S.e)*sin(LI.latitude)*sin(LI.latitude));
    LI.X=(Ntemp+LI.height)*cos(LI.latitude)*cos(LI.longitude);
    LI.Y=(Ntemp+LI.height)*cos(LI.latitude)*sin(LI.longitude);
    LI.Z=(Ntemp*(1-S.e)*(1-S.e)+LI.height)*sin(LI.latitude);
    %��̬����
    Qz=rv2q(-zeta);
    Qr=rv2q(rvet);
    Qn=qmul(I.Qnb,Qr);
    I.Qnb=qmul(Qz,Qn);
    I.Qnb=I.Qnb/norm(I.Qnb);%��Ԫ����һ��
    I.Cnb=Q2DCM(I.Qnb);
    Euler = DCM2Euler(I.Cnb,LI.gama);
    LI.sita=Euler(1);LI.gama=Euler(2);LI.psi=Euler(3);
