clear all;
clc;
format ('compact');
format ('long', 'g');
addpath include;             %  �������ջ�����
addpath geoFunctions;        %  ��λ������غ���
addpath INSFunctions;        %  �����ߵ�������غ���
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% ��ʼ���������� 
global S;
% INS
S.PI = 3.14159265358979323846 ;% pi
S.We =0.00007292115;% ������ת������
S.Re =6378137.0;% �뾶
S.e  =0.003352813;
S.Con_d2r    =1.745329251994330e-002;   % ��ת�򻡶�
S.Con_r2d    =5.729577951308232e+001;   % ����ת���
S.Con_dh2rs  =4.848136811095360e-006;   % d/h to rad/s 
S.c = 299792458;
% GPS
S.msToProcess = 543000;                 % 543000;%[ms]�������������
S.fileName = 'C:\Users\yht\Desktop\SDI\data\GPSL1CA_RoundDatagpsL12_114.995s_8bit.raw';% ��������·��
S.IF = 0e6;                % ��Ƶ
S.codeFreqBasis = 1.023e6; % ��Ƶ��
S.codeLength = 1023;       % �볤
S.samplingFreq = 2.5e6;    % ����Ƶ��
S.ms = 20;                 % ����ۻ�����
S.N = floor(1000/S.ms);     % ���ٴλ����Ժ󣬽���һ��Kalman�˲� 50
S.numberOfChannels = 11;   % ͨ����
S.Tu = 1e-3;               % ��ɻ���ʱ��
S.FSN = S.samplingFreq*S.Tu; % ������
S.B = S.samplingFreq/2;      % ����Ƶ��
S.T = S.Tu*S.ms;             % ����ɻ���ʱ��
S.navSolRate         = 1000/S.ms/S.N;   % �������� [Hz]
S.skipNumberOfSamples     = 0*2.5e6;
S.dataType = 'int8';
S.fileType = 2;
%%  DLL��·��������
S.dllDampingRatio         = 0.7;  % ����ϵ��
S.dllNoiseBandwidth       = 1;    % ��������    %[Hz]
S.dllCorrelatorSpacing    = 0.2;  % ��ؼ��    %[chips]
%% PLL��·��������
S.pllDampingRatio         = 0.7;  % ����ϵ��
S.pllNoiseBandwidth       = 18;   % ��������      %5��18;      %[Hz]
%% FLL��·��������
S.fllDampingRatio         = 0.7;  % ����ϵ��
S.fllNoiseBandwidth       = 10;   % ��������      %3��10;      %[Hz]
%% ���ǲ�������
S.startOffset = 68.802;       %[ms] Initial sign. travel time ��ʼ��־ ����ʱ��
S.CNo.accTime = 0.001;% Accumulation interval in Tracking (in Sec) ���ٹ����е��ۼ�ʱ��
S.CNo.enableVSM = 1;  % Show C/No during Tracking;1-on;0-off; �ڸ��ٹ������Ƿ������ʾ�����
S.CNo.VSMinterval = 1000;% 400;% Accumulation interval for computing VSM C/No (in ms) VSM ���������ʱ����
S.CNo.PRM_K=200;       % Accumulation interval for computing PRM C/No (in ms)  PRM ���������ʱ����
S.CNo.PRM_M=20;        % No. of samples to calculate narrowband power;         ����խ�����ʵĲ�����
S.CNo.MOMinterval=200; % Accumulation interval for computing MOM C/No (in ms)  MOM ���������ʱ���� 
% �ų������������źŽǶ���ֵ
S.elevationMask      = 10;           %[degrees 0 - 90]
% Enable/dissable use of tropospheric correction �����У��
S.useTropCorr        = 0;            % 0 - Off
% X ��·�˲�����
X.start = 607;%[ms]
X.LIstart = 30000/S.ms/S.N;%30000/S.ms;%[ms] 30000/20/50 ��30�뿪ʼ
X.N = floor(S.msToProcess/S.ms);% 543000/20
%% PLL FLL DLL��·��������
a_LF = 1.1; % PLL�����׻�����
b_LF = 2.4;
K_temp_LF = (a_LF*b_LF^2+a_LF^2-b_LF)/(4*(a_LF*b_LF-1));
wn=S.pllNoiseBandwidth/K_temp_LF;
% FLL�Ķ��׻�����
xi_FLL = 0.707;
wn_FLL = 2*S.fllNoiseBandwidth/(xi_FLL+1/(4*xi_FLL));
X.T_coh = S.Tu*S.ms;
X.C1 = 1/X.T_coh * (8*b_LF*wn*X.T_coh+2*wn^3*X.T_coh^3) /...% SU Filter Only: PLL Filter Coefficients  P18
    (4*b_LF*wn*X.T_coh+2*a_LF*wn^2*X.T_coh^2+wn^3*X.T_coh^3+8);
X.C2 = 1/X.T_coh * (8*a_LF*wn^2*X.T_coh^2-4*wn^3*X.T_coh^3) /...
    (4*b_LF*wn*X.T_coh+2*a_LF*wn^2*X.T_coh^2+wn^3*X.T_coh^3+8);
X.C3 = 1/X.T_coh * (8*wn^3*X.T_coh^3) /...
    (4*b_LF*wn*X.T_coh+2*a_LF*wn^2*X.T_coh^2+wn^3*X.T_coh^3+8);    
X.C1_FLL = 1/X.T_coh * (8*xi_FLL*wn_FLL*X.T_coh) /...% SU Filter Only: FLL Filter Coefficients
    (4+4*xi_FLL*wn_FLL*X.T_coh+(wn_FLL*X.T_coh)^2);
X.C2_FLL = 1/X.T_coh * (4*(wn_FLL*X.T_coh)^2) /...
    (4+4*xi_FLL*wn_FLL*X.T_coh+(wn_FLL*X.T_coh)^2); 
X.earlyLateSpc = S.dllCorrelatorSpacing;
X.PDIcode = 0.001*S.ms;
% DLL���׻�·����
[X.tau1code, X.tau2code] = calcLoopCoef(S.dllNoiseBandwidth,S.dllDampingRatio,1.0);  
% ���� PLL��·                               
%  X.PDIcarr = 0.001*S.ms;
% [X.tau1carr, X.tau2carr] = calcLoopCoef(S.pllNoiseBandwidth, ...
%                                     S.pllDampingRatio,0.25);
%% ��������
if (S.fileType==1)
    X.dataAdaptCoeff=1;
else
    X.dataAdaptCoeff=2;
end
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% Init channels and trackingResults ��ʼ��ͨ���͸��ٽ��
[fid, message] = fopen(S.fileName, 'rb');
if(fid>0)
    load 'C:\Users\yht\Desktop\SDI\data\eph';
    load 'C:\Users\yht\Desktop\SDI\data\Init.mat';
    load 'C:\Users\yht\Desktop\SDI\data\MMQ.mat';
%     load IP.mat;
%% �˲�������ʼ��
    [LI,I] = LIInit();
    % LI���������
%     ��GPS��ʼʱ�̶���Ĺ��Ե�������
%     γ���߶ȡ��������ٶȡ������������ǡ������Ǽ��ٶ���ƫ
%     ������ת������nϵ��bϵ֮���ת������ ������������� kalman�˲�P��Q��
end
channel.PRN = 0;
channel.status = 0;
channel.caCode = zeros(1, 1025);
channel.codeFreq = 0;
channel.dcodeFreq = 0;
channel.remCodePhase  = 0;
channel.carrFreq = 0;
channel.dcarrFreq = 0;
channel.carrFreqBasis =0;
channel.carrJust = 0;
channel.remCarrPhase  =0;
channel.codeNco   = 0;
channel.codeError = 0;
channel.carrNco   = 0;
channel.carrError = 0;
channel.oldCodeNco   = 0;% Init.oldCodeNco(m);
channel.oldCodeError = 0;% Init.oldCodeError(m);
channel.oldCarrNco   = 0;% Init.oldCarrNco(m);
channel.oldCarrError = 0;% Init.oldCarrError(m);
channel.codePhaseStep = 0;% ����λ����
channel.blksize =0;% �봰�ĳ���
channel.samplepos=0;% ��ʼ����λ��
channel.I_E=0.0;
channel.I_P=0.0;
channel.I_L=0.0;
channel.Q_E=0.0;
channel.Q_P=0.0;
channel.Q_L=0.0;
channel.LF_t1 = 0;
channel.LF_t2 = 0;
channel.LF_t3 = 0;
channel.LF_t4 = 0;
channel = repmat(channel, 1, S.numberOfChannels);
%% ͨ��������ʼ��
for m = 1:S.numberOfChannels
    channel(m).PRN = Init.PRN(m);
    channel(m).status = Init.status(m);
    if (channel(m).PRN ~= 0)
        channel(m).caCode = generateCAcode(channel(m).PRN);
        channel(m).caCode = [channel(m).caCode(1023) channel(m).caCode channel(m).caCode(1)];% ����Ϊ1025 ��ǰ�ͺ��һ����Ƭ
        channel(m).codeFreq = Init.codeFreq(m);
        channel(m).dcodeFreq = 0;
        channel(m).remCodePhase  = Init.remCodePhase(m);
        channel(m).carrFreq = Init.carrFreq(m);
        channel(m).dcarrFreq = 0;
        channel(m).carrFreqBasis = Init.carrFreqBasis(m);
        channel(m).carrJust = 0;
        channel(m).remCarrPhase  = Init.remCarrPhase(m);
        channel(m).codeNco   = 0;
        channel(m).codeError = 0;
        channel(m).carrNco   = 0;
        channel(m).carrError = 0;
        channel(m).oldCodeNco   = 0;% Init.oldCodeNco(m);
        channel(m).oldCodeError = 0;% Init.oldCodeError(m);
        channel(m).oldCarrNco   = 0;% Init.oldCarrNco(m);
        channel(m).oldCarrError = 0;% Init.oldCarrError(m);
        channel(m).codePhaseStep = channel(m).codeFreq / S.samplingFreq;% ����λ����
        channel(m).blksize = ceil((S.codeLength-channel(m).remCodePhase) / channel(m).codePhaseStep);% �봰�ĳ���
        channel(m).samplepos=ceil(Init.initSamplePos(m));% ��ʼ����λ��
        channel(m).I_E=0.0;
        channel(m).I_P=0.0;
        channel(m).I_L=0.0;
        channel(m).Q_E=0.0;
        channel(m).Q_P=0.0;
        channel(m).Q_L=0.0;
        channel(m).LF_t1 = 0;
        channel(m).LF_t2 = 0;
        channel(m).LF_t3 = 0;
        channel(m).LF_t4 = 0; 
    end
end
%% ����ͨ�������ʼ��
trackResults.status         = '-';           % No tracked signal, or lost lock
trackResults.absoluteSample = zeros(1, X.N); % ���Բ�����
trackResults.codeFreq       = inf(1, X.N);
trackResults.remCodePhase   = zeros(1, X.N);
trackResults.carrFreq       = inf(1, X.N);
trackResults.Vd             = zeros(1, X.N);
trackResults.remCarrPhase   = zeros(1, X.N);
trackResults.I_P            = zeros(1, X.N);
trackResults.I_E            = zeros(1, X.N);
trackResults.I_L            = zeros(1, X.N);
trackResults.Q_E            = zeros(1, X.N);
trackResults.Q_P            = zeros(1, X.N);
trackResults.Q_L            = zeros(1, X.N);
trackResults.dllDiscr       = inf(1, X.N);
trackResults.dllDiscrFilt   = inf(1, X.N);
trackResults.pllDiscr       = inf(1, X.N);
trackResults.pllDiscrFilt   = inf(1, X.N);
% trackResults.CNo.VSMValue = ...
%     zeros(1,floor(S.msToProcess/S.CNo.VSMinterval));
% trackResults.CNo.VSMIndex = ...
%     zeros(1,floor(S.msToProcess/S.CNo.VSMinterval));
trackResults = repmat(trackResults, 1, S.numberOfChannels);
for m = 1:S.numberOfChannels
    if (channel(m).PRN ~= 0)
        trackResults(m).PRN     = channel(m).PRN;
        trackResults(m).status  = channel(m).status;
    end
end 
%% ����Ϸ��ز�����ʼ��
X.vsmCnt=0;
X.satElev = inf(1, S.numberOfChannels);
X.Vd = zeros(1, S.numberOfChannels);
X.Vdt = zeros(1, S.numberOfChannels);
X.Vdt_old = zeros(1, S.numberOfChannels);
X.activeChnList = find([trackResults.status] ~= '-');
X.readyChnList = X.activeChnList;
X.svTimeTable=transTimeTable(X.activeChnList,trackResults,subFrameStart,TOW,S);
X.navStep = 1000/S.ms/S.navSolRate;
X.currMeasNr = 0;
X.currINS = 0;
X.sample_clk_bias_shift = 50;
sampleNum0 = S.skipNumberOfSamples+min( Init.initSamplePos)-X.sample_clk_bias_shift;

%% start data process
startTime = now;
% disp (['   Processing started at ', 	(startTime)]);  
fprintf('��ʼʱ��Ϊ��%f\n',startTime);
for loopCnt =  1:S.msToProcess
    % ѭ����ʼ
    fprintf('����Ͻ����%dms\n',loopCnt);
    % tracking
    for m = 1:S.numberOfChannels
        if(m==1)
            minpos = channel(m).samplepos;
            maxpos = channel(m).samplepos;
            maxblksize = channel(m).blksize;
        else
            if(minpos>channel(m).samplepos)
                minpos = channel(m).samplepos;
            end
            if(maxpos<channel(m).samplepos)
                maxpos = channel(m).samplepos;
            end
            if(maxblksize<channel(m).blksize)
                maxblksize = channel(m).blksize;
            end
        end
    end
    fseek(fid, X.dataAdaptCoeff*(minpos-1),'bof');
    %% ��ȡԭʼ���ݣ� ��ȡ����ͨ����������ԭʼ���� ��������ͨ�������ݽ�ȡ ����Ƶ��Ϊ2.5e6 ʱ��Ϊ0.001 2500
    [rawSignal0, samplesRead0] = fread(fid,X.dataAdaptCoeff*(maxpos-minpos+maxblksize), S.dataType);
    %%  %%%%%%%%%%%%%%%%%%%%%%%%%�źŸ���%%%%%%%%%%%%%%%%%%%%%%%%%%
    for m = 1:S.numberOfChannels
        % ÿ������ͨ����1msԭʼ��������
        rawSignal = rawSignal0((channel(m).samplepos-minpos)*X.dataAdaptCoeff...
            +1:(channel(m).samplepos-minpos+channel(m).blksize)*X.dataAdaptCoeff)';    
        Pn=100;
        CN_down = 0;%33
%         if(loopCnt<50000)
%             ;
%         elseif(loopCnt>=50000&&loopCnt<100000)
%             rawSignal = (rawSignal/sqrt(10^(CN_down*(loopCnt-50000)/50000/10))) + sqrt(Pn^2-Pn^2./(10.^(CN_down*(loopCnt-50000)/50000/10)))*randn(1,length(rawSignal));
%         else
%             rawSignal = (rawSignal/sqrt(10^(CN_down/10))) + sqrt(Pn^2-Pn^2./(10.^(CN_down/10)))*randn(1,length(rawSignal));
%         end

%         if(loopCnt<10000)
%             ;
%         elseif(loopCnt>=10000&&loopCnt<20000)
%             rawSignal = (rawSignal/sqrt(10^(CN_down*(loopCnt-10000)/10000/10))) + sqrt(Pn^2-Pn^2./(10.^(CN_down*(loopCnt-10000)/10000/10)))*randn(1,length(rawSignal));
%         else
%             rawSignal = (rawSignal/sqrt(10^(CN_down/10))) + sqrt(Pn^2-Pn^2./(10.^(CN_down/10)))*randn(1,length(rawSignal));
%         end  
        
        if (X.dataAdaptCoeff==2)
            rawSignal1=rawSignal(1:2:end);
            rawSignal2=rawSignal(2:2:end);
            rawSignal = rawSignal1 + 1i .* rawSignal2;  %transpose vector
        end
        
        if(X.currMeasNr < X.LIstart)
            channel(m).carrFreq = channel(m).carrFreqBasis + channel(m).carrNco;
        elseif(X.currMeasNr == X.LIstart)
%           channel(m).carrFreq =channel(m).carrJust+ X.Vd(m);
            channel(m).carrFreq =channel(m).carrJust+ X.Vd0(m)+(channel(m).samplepos-sampleNum0)/S.FSN*channel(m).dcarrFreq;
            channel(m).LF_t1 = 0;
            channel(m).LF_t2 = 0;
            channel(m).LF_t3 = 0;
            channel(m).LF_t4 = 0;
        else
%       channel(m).carrFreq =channel(m).carrJust + channel(m).carrNco + X.Vd(m);
        channel(m).carrFreq =channel(m).carrJust + channel(m).carrNco + X.Vd0(m)+(channel(m).samplepos-sampleNum0)/S.FSN*channel(m).dcarrFreq;
        end
%       channel(m).codeFreq = S.codeFreqBasis - channel(m).codeNco;
        channel(m).codeFreq = S.codeFreqBasis - channel(m).codeNco - channel(m).carrFreq/1540;
        
       %%  ��ǰ�ͺ�ʱ�볤��
        tcode=(channel(m).remCodePhase-X.earlyLateSpc):channel(m).codePhaseStep:((channel(m).blksize-1)*channel(m).codePhaseStep+channel(m).remCodePhase-X.earlyLateSpc);
        tcode2 = ceil(tcode)+1;
        earlyCode=channel(m).caCode(tcode2);
        tcode=(channel(m).remCodePhase+X.earlyLateSpc):channel(m).codePhaseStep:((channel(m).blksize-1)*channel(m).codePhaseStep+channel(m).remCodePhase+X.earlyLateSpc);
        tcode2 = ceil(tcode)+1;
        lateCode=channel(m).caCode(tcode2);
        tcode=channel(m).remCodePhase:channel(m).codePhaseStep:((channel(m).blksize-1)*channel(m).codePhaseStep+channel(m).remCodePhase);
        tcode2 = ceil(tcode)+1;
        promptCode=channel(m).caCode(tcode2);
        channel(m).remCodePhase = (tcode(channel(m).blksize)+channel(m).codePhaseStep)-1023.0;
       %%  �ز��ź�
        time   = (0:channel(m).blksize) ./ S.samplingFreq;
        trigarg=((channel(m).carrFreq*2.0*pi).*time)+channel(m).remCarrPhase;
        channel(m).remCarrPhase = rem(trigarg(channel(m).blksize+1),(2*pi));
        carrsig=exp(1i.*trigarg(1:channel(m).blksize));
        qBasebandSignal = real(carrsig.*rawSignal);
        iBasebandSignal = imag(carrsig.*rawSignal);
        I_E = sum(earlyCode  .* iBasebandSignal);
        Q_E = sum(earlyCode  .* qBasebandSignal);
        I_P = sum(promptCode .* iBasebandSignal);
        Q_P = sum(promptCode .* qBasebandSignal);
        I_L = sum(lateCode   .* iBasebandSignal);
        Q_L = sum(lateCode   .* qBasebandSignal);
       
        channel(m).I_E=channel(m).I_E+I_E;
        channel(m).I_P=channel(m).I_P+I_P;
        channel(m).I_L=channel(m).I_L+I_L;
        channel(m).Q_E=channel(m).Q_E+Q_E;
        channel(m).Q_P=channel(m).Q_P+Q_P;
        channel(m).Q_L=channel(m).Q_L+Q_L;
        %% ��ͣ�ۼ� ֱ��20ms ����һ�μ��໷·���
        if(mod(loopCnt,S.ms)==0)
            if(loopCnt==S.ms)
                channel(m).I_P1=channel(m).I_P;
                channel(m).Q_P1=channel(m).Q_P;
                FLL=0;
            else
                dot=channel(m).I_P1*channel(m).I_P+channel(m).Q_P1*channel(m).Q_P;          % ��� ǰһʱ���뵱ǰʱ��
                crossProduct=channel(m).I_P1*channel(m).Q_P-channel(m).I_P*channel(m).Q_P1; % ��� ǰһʱ���뵱ǰʱ��
            %% FLL��·�������
                FLL = crossProduct*sign(dot)/(2*pi*(channel(m).I_P*channel(m).I_P+channel(m).Q_P*channel(m).Q_P));
                channel(m).I_P1 = channel(m).I_P;
                channel(m).Q_P1 = channel(m).Q_P; 
            end
            channel(m).carrError = atan(channel(m).Q_P / channel(m).I_P) / (2.0 * pi); % cycle
            %% �ز����������
            PD_output = channel(m).carrError;
            %% Ƶ�ʼ��������
            FD_output = FLL;
            %% �ز�NCOУ��
            channel(m).LF_t1 = channel(m).LF_t1 + PD_output * X.C3 + FD_output * X.C2_FLL * X.T_coh;
            channel(m).LF_t2 = channel(m).LF_t1 + PD_output * X.C2 + FD_output * X.C1_FLL * X.T_coh;
            channel(m).LF_t3 = channel(m).LF_t3 + channel(m).LF_t2;
            channel(m).LF_t4 = channel(m).LF_t3 + PD_output * X.C1;
            channel(m).carrNco = channel(m).LF_t4;
%           channel(m).carrFreq = channel(m).carrFreqBasis + channel(m).carrNco;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%question????
            %% ����������
            channel(m).codeError = (sqrt(channel(m).I_E * channel(m).I_E + channel(m).Q_E * channel(m).Q_E)...
                - sqrt(channel(m).I_L * channel(m).I_L + channel(m).Q_L * channel(m).Q_L)) / ...
                (sqrt(channel(m).I_E * channel(m).I_E + channel(m).Q_E * channel(m).Q_E)...
                + sqrt(channel(m).I_L * channel(m).I_L + channel(m).Q_L * channel(m).Q_L));
            %% ��NCOУ��
            channel(m).codeNco = channel(m).oldCodeNco + (X.tau2code/X.tau1code) * ...
                (channel(m).codeError - channel(m).oldCodeError) + ...
                channel(m).codeError * (X.PDIcode/X.tau1code);
            channel(m).oldCodeNco   = channel(m).codeNco;
            channel(m).oldCodeError = channel(m).codeError;
%           channel(m).codeFreq = S.codeFreqBasis - channel(m).codeNco - channel(m).carrFreq/1540;
            channel(m).I_E=0.0;
            channel(m).I_P=0.0;
            channel(m).I_L=0.0;
            channel(m).Q_E=0.0;
            channel(m).Q_P=0.0;
            channel(m).Q_L=0.0;
        end
%             channel(m).carrFreq = channel(m).carrFreq+channel(m).dcarrFreq;
%             channel(m).codeFreq = channel(m).codeFreq+channel(m).dcodeFreq;
%         if(X.currMeasNr < X.LIstart)
%             channel(m).carrFreq = channel(m).carrFreqBasis + channel(m).carrNco;
%         elseif(X.currMeasNr == X.LIstart)
%             channel(m).carrFreq = X.Vd(m);
%             channel(m).LF_t1 = 0;
%             channel(m).LF_t2 = 0;
%             channel(m).LF_t3 = 0;
%             channel(m).LF_t4 = 0;
%         else
%             channel(m).carrFreq = channel(m).carrNco + X.Vd(m);
%         end
%         channel(m).codeFreq = S.codeFreqBasis - channel(m).codeNco - channel(m).carrFreq/1540;

        channel(m).samplepos = channel(m).samplepos+channel(m).blksize;
        channel(m).codePhaseStep = channel(m).codeFreq / S.samplingFreq;
        channel(m).blksize = ceil((S.codeLength-channel(m).remCodePhase)/channel(m).codePhaseStep);

        trackResults(m).codeFreq(loopCnt) = channel(m).codeFreq;
        trackResults(m).remCodePhase(loopCnt) = channel(m).remCodePhase;
        trackResults(m).carrFreq(loopCnt) = channel(m).carrFreq;
        trackResults(m).remCarrPhase(loopCnt) = channel(m).remCarrPhase;
        trackResults(m).I_E(loopCnt) = I_E;
        trackResults(m).I_P(loopCnt) = I_P;
        trackResults(m).I_L(loopCnt) = I_L;
        trackResults(m).Q_E(loopCnt) = Q_E;
        trackResults(m).Q_P(loopCnt) = Q_P;
        trackResults(m).Q_L(loopCnt) = Q_L;
        trackResults(m).dllDiscr(loopCnt) = channel(m).codeError;
        trackResults(m).dllDiscrFilt(loopCnt) = channel(m).codeNco;
        trackResults(m).pllDiscr(loopCnt) = channel(m).carrError;
        trackResults(m).pllDiscrFilt(loopCnt) = channel(m).carrNco;
        trackResults(m).absoluteSample(loopCnt) = channel(m).samplepos-channel(m).remCodePhase/channel(m).codePhaseStep;
        trackResults(m).Vd(loopCnt) = X.Vd(m);
    end
    %%  %%%%%%%%%%%%%%%%%%%%%%%%%���ٽ������%%%%%%%%%%%%%%%%%%%%%%%%%%
               
    % tracking������--����--�˲����������ڷֿ���
%     [trackResults, channel] =trackings(fid, channel,  trackResults, X, loopCnt, S);
%%  ����ȼ���
    % CN0 and lock-detection 
    if (S.CNo.enableVSM == 1)
        if (rem(loopCnt,S.CNo.VSMinterval)==0) % ÿ1000�ν���һ���������� �൱��1s���һ��
            X.vsmCnt = X.vsmCnt+1;
            for m = 1:S.numberOfChannels
                CNoValue=CNoVSM(trackResults(m).I_P(loopCnt-S.CNo.VSMinterval+1:loopCnt),...
                    trackResults(m).Q_P(loopCnt-S.CNo.VSMinterval+1:loopCnt),S.CNo.accTime); % ������ͷ����������
                trackResults(m).CNo.VSMValue(X.vsmCnt) = CNoValue;
                trackResults(m).CNo.VSMIndex(X.vsmCnt) = loopCnt;
            end
        end
    end
    % navSolute ��������
    if(mod(loopCnt,S.ms*S.N)==0) % S.ms*S.N = 1000   һ�����һ��
        X.currMeasNr = X.currMeasNr+1;
        X.sampleNum=floor(X.currMeasNr*S.samplingFreq/S.navSolRate...
            +S.skipNumberOfSamples+min( Init.initSamplePos))-X.sample_clk_bias_shift;
        % ����3��� 
        if(X.currMeasNr>3)
            X.activeChnList = intersect(find(X.satElev >= S.elevationMask), ...
                X.readyChnList);
%             X.activeChnList = [1,3,5,6,7];
            navSolutions.channel.PRN(X.activeChnList, X.currMeasNr) = ...
                [trackResults(X.activeChnList).PRN];
            navSolutions.channel.el(:, X.currMeasNr) = NaN(S.numberOfChannels, 1);
            navSolutions.channel.az(:, X.currMeasNr) = NaN(S.numberOfChannels, 1);
            [navSolutions,X] = navSolution_s(navSolutions,trackResults,X,loopCnt,S,eph);
%           ��������
% navSolution:
%             channel  ͨ����
%             DOP      ��������
%             XYZ      ���ջ���ECEFλ������
%             dt dtt   ��ƫ����Ư
%             Vx Vy Vz ���ջ���ECEF�ٶ�
%             latitude γ��
%             longitude ����
%             height    �߶�
%             utmzone   ��
%             ENU       ����������
%             rxTime    ����ʱ��
%             absoluteSample ������
%             rawRxTime  ԭʼ����ʱ��
%             Vn         �������µ��ٶ�
%          X: rawP α��
%             rawdP α�ٶ�
%             satPositions ����λ���ٶ�
        end
    % Loose Integrated �����
        if(X.currMeasNr>5) % ���Կ�������˲���Ƶ��
            for m = 1:S.numberOfChannels
%                 LI.R(m,m) = 293^2/2/(S.ms*S.Tu*10^(trackResults(m).CNo.VSMValue(end)/10))^2 + ...
%                     293^2/4/(S.ms*S.Tu*10^(trackResults(m).CNo.VSMValue(end)/10));
              %% ����Э�������
                LI.R(m,m) = (S.c/1.023e6)^2*2*S.dllCorrelatorSpacing/(4*S.ms*S.Tu*10^(trackResults(m).CNo.VSMValue(end)/10))*(1+2/(2-2*S.dllCorrelatorSpacing)/(S.ms*S.Tu*10^(trackResults(m).CNo.VSMValue(end)/10)));
                LI.R(m+S.numberOfChannels,m+S.numberOfChannels) = (S.c/(S.PI*S.ms*S.Tu*1575.42e6))^2*(2/(S.ms*S.Tu*10^(trackResults(m).CNo.VSMValue(end)/10))^2 + ...
                    2/(S.ms*S.Tu*10^(trackResults(m).CNo.VSMValue(end)/10)));
            end
               [LI,I] = LIKalman(LI,I,X);
            if(X.currMeasNr > X.LIstart)
                sampleNum0 = loopCnt*S.samplingFreq/1000+S.skipNumberOfSamples+min( Init.initSamplePos)-X.sample_clk_bias_shift;
                [index_a,index_b,transmitTime0]= findTransTime(sampleNum0,X.readyChnList,X.svTimeTable,trackResults);
                [satPositions0, satClkCorr0] = satpos(transmitTime0,[trackResults(X.readyChnList).PRN],eph);
                [nRn,nRe,gn,Wie,Wep] = EarthCalc(LI.latitude,LI.height,LI.vn);
                Ntemp=S.Re/sqrt(1-S.e*(2-S.e)*sin(LI.latitude)*sin(LI.latitude));
                LI.X=(Ntemp+LI.height)*cos(LI.latitude)*cos(LI.longitude);
                LI.Y=(Ntemp+LI.height)*cos(LI.latitude)*sin(LI.longitude);
                LI.Z=(Ntemp*(1-S.e)*(1-S.e)+LI.height)*sin(LI.latitude);
                for m =1:length(X.readyChnList)  %1:S.numberOfChannels
                    lx = satPositions0(1,m) - LI.X;
                    ly = satPositions0(2,m) - LI.Y;
                    lz = satPositions0(3,m) - LI.Z;
                    norm_a = sqrt(lx*lx+ly*ly+lz*lz);
                    a=[lx;ly;lz]/norm_a;
                    channel(m).carrJust = channel(m).carrJust - (I.Cne'*LI.vnError)'*a/S.c*1575.42e6;
                end
            end
        end
        %��������
%         Save_pos(:,X.currMeasNr)=[LI.latitude;LI.longitude;LI.height];
%         Save_vn(:,X.currMeasNr)=LI.vn;
%         Save_phi(:,X.currMeasNr)=DCM2Euler(I.Cnb,LI.gama);
%         LI.sita=Save_phi(1,X.currMeasNr);LI.gama=Save_phi(2,X.currMeasNr);LI.psi=Save_phi(3,X.currMeasNr);
    end
    if(mod(loopCnt,10)==0)
        if(X.currMeasNr>3)
            sampleNum0 = loopCnt*S.samplingFreq/1000+S.skipNumberOfSamples+min( Init.initSamplePos)-X.sample_clk_bias_shift;
            [index_a,index_b,transmitTime0]= findTransTime(sampleNum0,X.readyChnList,X.svTimeTable,trackResults);
            [satPositions0, satClkCorr0] = satpos(transmitTime0,[trackResults(X.readyChnList).PRN],eph);
            [nRn,nRe,gn,Wie,Wep] = EarthCalc(LI.latitude,LI.height,LI.vn);
            Ntemp=S.Re/sqrt(1-S.e*(2-S.e)*sin(LI.latitude)*sin(LI.latitude));
            LI.X=(Ntemp+LI.height)*cos(LI.latitude)*cos(LI.longitude);
            LI.Y=(Ntemp+LI.height)*cos(LI.latitude)*sin(LI.longitude);
            LI.Z=(Ntemp*(1-S.e)*(1-S.e)+LI.height)*sin(LI.latitude);
            for m =1:length(X.readyChnList)  %1:S.numberOfChannels
                lx = satPositions0(1,m) - LI.X; 
                ly = satPositions0(2,m) - LI.Y;
                lz = satPositions0(3,m) - LI.Z;
                norm_a = sqrt(lx*lx+ly*ly+lz*lz);
                a=[lx;ly;lz]/norm_a;
                X.Vd0(m) = (satPositions0(4:6,m)- I.Cne'*LI.vn)'*a/S.c*1575.42e6; % ������Ƶ������
            end
        end
        
        X.currINS = X.currINS+1;
        %%   �ߵ�����10ms����һ�� ˫������̬����
        [LI,I] = INSCycle2(LI,I,X,MMQ);
        
        if(X.currMeasNr>3)
            transmitTime1 = transmitTime0 + 0.04;
            [satPositions1, satClkCorr1] = satpos(transmitTime1,[trackResults(X.readyChnList).PRN],eph);
            [nRn,nRe,gn,Wie,Wep] = EarthCalc(LI.latitude,LI.height,LI.vn);
            Ntemp=S.Re/sqrt(1-S.e*(2-S.e)*sin(LI.latitude)*sin(LI.latitude));
            LI.X=(Ntemp+LI.height)*cos(LI.latitude)*cos(LI.longitude);
            LI.Y=(Ntemp+LI.height)*cos(LI.latitude)*sin(LI.longitude);
            LI.Z=(Ntemp*(1-S.e)*(1-S.e)+LI.height)*sin(LI.latitude);
            for m = 1:length(X.readyChnList)
                lx = satPositions1(1,m) - LI.X;
                ly = satPositions1(2,m) - LI.Y;
                lz = satPositions1(3,m) - LI.Z;
                norm_a = sqrt(lx*lx+ly*ly+lz*lz);
                a=[lx;ly;lz]/norm_a;
                X.Vd1(m) = (satPositions1(4:6,m)- I.Cne'*LI.vn)'*a/S.c*1575.42e6;
                channel(m).dcarrFreq = (X.Vd1(m)-X.Vd0(m))/10;% ������Ƶ������
            %     channel(m).dcodeFreq = -(X.Vd1(m)-X.Vd0(m))/20/1540;
            end
            %     X.Vd = X.Vd0;
        end
        Save_pos(:,X.currINS) = [LI.latitude;LI.longitude;LI.height];
        Save_vn(:,X.currINS)  = LI.vn;
        Save_phi(:,X.currINS) = [LI.sita;LI.gama;LI.psi];
%       LI.sita=Save_phi(1,X.currINS);LI.gama=Save_phi(2,X.currMeasNr);LI.psi=Save_phi(3,X.currMeasNr);
    end
    if(X.currMeasNr>4)
        X.Vdt_old = X.Vd;
        if(mod(loopCnt,10)==0 && loopCnt>10)
            X.Vdt = X.Vd0 + (X.Vd1-X.Vd0)/10;
        elseif(loopCnt>10)
            X.Vdt = X.Vdt + (X.Vd1-X.Vd0)/10;
        end
        X.Vd = X.Vdt;
%     X.Vd = 99/100*X.Vdt_old + 1/100* X.Vdt;
    end
end
fclose(fid);
trackResults = calculateCNoPRM(trackResults,S);
trackResults = calculateCNoMOM(trackResults,S);
save('trackingResults', ...
        'trackResults', 'S', 'channel');
save('navSolutions','navSolutions','eph','X')
save('saveINS','Save_pos','Save_vn','Save_phi');