function acqResults = acquisition(signal, settings)
%Function performs cold start acquisition on the collected "data". It
%searches for GPS signals of all satellites, which are listed in field
%"acqSatelliteList" in the settings structure. Function saves code phase
%and frequency of the detected signals in the "acqResults" structure.
%acqResults = acqHighSensitivity(signal, settings)
%
%   Inputs:
%       signal        - raw signal from the front-end
%       settings      - Receiver settings. Provides information about
%                       sampling and intermediate frequencies and other
%                       parameters including the list of the satellites to
%                       be acquired.
%   Outputs:
%       acqResults    - Function saves code phases and frequencies of the
%                       detected signals in the "acqResults" structure. The
%                       field "carrFreq" is set to 0 if the signal is not
%                       detected for the given PRN number.

%--------------------------------------------------------------------------


%% Initialization =========================================================

% C/A code frequency
chipRate        = settings.codeFreqBasis;
% C/A code length
codeLength      = settings.codeLength;
% No. of code periods for coherent integration
cohCodePeriods  = settings.acquisition.cohCodePeriods;
% Doppler Search Band in Hz
doppSearchBand  = settings.acqSearchBand*1000;%In Hz
% Sampling Frequency
samplingFreq    = settings.samplingFreq;
% Sampling period
ts              = 1 / settings.samplingFreq;
% FFT Length should be at least 2*code_length*coh_code_periods
fftLength       = 2^ceil(log2(2*codeLength*cohCodePeriods));
samplesPerChip  = fftLength / (codeLength * cohCodePeriods);
freqStep        = chipRate / (codeLength * cohCodePeriods);
% No. of frequency bins to search on each side
freqBins        = doppSearchBand/freqStep;
% Samples per each coherent sum
NoOfSamples     = (samplingFreq/chipRate) * codeLength * cohCodePeriods; %2500 * 2

% Samples per ms
samplesPerMs    = (samplingFreq/chipRate) * codeLength;


%% Remove Carrier and Resample ============================================
% No. of non-coherent summations 
nonCohSums      = settings.acquisition.nonCohSums;
cohSamplesNo    = floor(NoOfSamples);

inputfftA = zeros(nonCohSums,fftLength);
inputfftB = zeros(nonCohSums,fftLength);

% Resample parameters
[resampleNum,resampleDenom] = rat(fftLength/NoOfSamples);
 
% Phase Points
expPhasePoints = exp(1i*2*pi*settings.IF*ts*(0:(cohSamplesNo-1)));

for index = 1:nonCohSums

    % Read alternate signal block
    signalA = signal(2*(index-1)*cohSamplesNo+1:2*(index-1)*cohSamplesNo+cohSamplesNo);
    signalB = signal((2*index-1)*cohSamplesNo+1:2*index*cohSamplesNo);

    % Remove the carrier
    inputA = expPhasePoints .* signalA;
    inputB = expPhasePoints .* signalB;

    % Resample the baseband signal
    inputA_resamp = resample(inputA,resampleNum,resampleDenom);
    inputB_resamp = resample(inputB,resampleNum,resampleDenom);

    % Convert the baseband signal to frequency domain
    inputfftA(index,:) = fft(inputA_resamp(1:fftLength));
    inputfftB(index,:) = fft(inputB_resamp(1:fftLength));

end

%--- Initialize acqResults ------------------------------------------------
% Carrier frequencies of detected signals
acqResults.carrFreq     = zeros(1, 32);
% Raw C/A code phases of detected signals
acqResults.rawCodePhase    = zeros(1, 32);
% Refined C/A code phases of detected signals
acqResults.codePhase    = zeros(1, 32);
% Chip rate of C/A code plus doppler
acqResults.codeRate     = zeros(1, 32);
% Correlation peak ratios of the detected signals
acqResults.peakMetric   = zeros(1, 32);

%% Remove Code and Correlate ==============================================
fprintf('(');

%-----For each PRN in the acqSatellite list--------------------------------
for PRN = settings.acqSatelliteList

    %Get the sampled code and compute the FFT
    sampledCode = sampledCAcode(PRN,samplesPerChip*chipRate,fftLength);
    fftCode = fft(sampledCode);
    fftConjCode = conj(fftCode);

    maxCorrAmount = 0;
    freqIndex = 0;

    % For each Doppler search bin
    for binIndex =-freqBins/2:freqBins/2  

        freqIndex = freqIndex + 1;
        corrA = zeros(1,fftLength);
        corrB = zeros(1,fftLength);

        %Loop through the non-coherent sums
        for index = 1:nonCohSums

            %Circular shift the baseband in frequency domain
            inputfftA_shift = circshift(inputfftA(index,:),[0,binIndex]);
            inputfftB_shift = circshift(inputfftB(index,:),[0,binIndex]);

            %Correlate with the code
            mixed_fftsA = inputfftA_shift .* fftConjCode;
            mixed_fftsB = inputfftB_shift .* fftConjCode;

            %Compute IFFT and sum the results for non-coherent summation
            corrA = corrA + abs(ifft(mixed_fftsA));
            corrB = corrB + abs(ifft(mixed_fftsB));

        end

        %---Find the maximum correlation and store the results---------
        maxCorrA = max(corrA);
        maxCorrB = max(corrB);

        maxCorrCurrentFreq = max(maxCorrA,maxCorrB);

        if ( maxCorrCurrentFreq > maxCorrAmount )
            maxCorrAmount = maxCorrCurrentFreq;
            maxCorrFreqIndex = freqIndex;
            if ( maxCorrB > maxCorrA )
                maxCorr1ms = corrB(1:round(samplesPerChip*codeLength));
            else
                maxCorr1ms = corrA(1:round(samplesPerChip*codeLength));
            end
        end

    end

   acqCarrFreq = (maxCorrFreqIndex - (freqBins/2+1))*freqStep + settings.IF; 

    % Calculate the Peak Height
    [peakHeight,codephaseIndex] = max(maxCorr1ms);
    
    %--- Find 1 chip wide C/A code phase exclude range around the peak ----
    excludeRangeIndex1 = codephaseIndex - ceil(samplesPerChip);
    excludeRangeIndex2 = codephaseIndex + ceil(samplesPerChip);
    
    %--- Correct C/A code phase exclude range if the range includes array
    %boundaries
    if excludeRangeIndex1 < 1  % peak near beginning of code period
        codePhaseRange = excludeRangeIndex2 : ...
            (length(maxCorr1ms) + excludeRangeIndex1);

    elseif excludeRangeIndex2 > length(maxCorr1ms)  % peak near end of code period
        codePhaseRange = (excludeRangeIndex2 - length(maxCorr1ms)) : ...
            excludeRangeIndex1;
    else
        codePhaseRange = [1:excludeRangeIndex1, ...
            excludeRangeIndex2 : length(maxCorr1ms)];
    end

    %--- Find the second highest correlation peak in the same freq. bin ---
    noise_max = max(maxCorr1ms(codePhaseRange));

    % Calculate the Peak Metric and the Code Phase
    acqResults.peakMetric(PRN)  = peakHeight / noise_max;
    acqResults.rawCodePhase(PRN)   = round((codephaseIndex/(fftLength/cohCodePeriods))*(samplingFreq/(chipRate/codeLength)));

    if (acqResults.peakMetric(PRN)) > settings.acqThreshold
        fprintf('%02d ', PRN);
        
        % Refine the code phase added by Xiaofan Li on 2/2/2009
        % Phase Points
        samplesPerCode=round(samplesPerMs);
        samplesPerCoh=round(samplesPerMs*cohCodePeriods);
        phasePoints= exp(1i*2*pi*acqCarrFreq*ts*(0:(samplesPerCoh-1)));
        
        corr1=zeros(1,samplesPerCoh);
        corr2=zeros(1,samplesPerCoh);
        
        % generate C/A code
        sampledCode = sampledCAcode(PRN,settings.samplingFreq,samplesPerCoh);
        
        for index=1:nonCohSums
            signal1 = signal(1+(index-1)*2*samplesPerCoh:(2*index-1)*samplesPerCoh);
            signal2 = signal((2*index-1)*samplesPerCoh+1:2*index*samplesPerCoh);
            % remove carrier
            input1 = phasePoints .* signal1;
            input2 = phasePoints .* signal2;
            
            mixed_ffts1 = fft(input1) .* conj(fft(sampledCode));
            mixed_ffts2 = fft(input2) .* conj(fft(sampledCode));
            corr1 = corr1+abs(ifft(mixed_ffts1));
            corr2 = corr2+abs(ifft(mixed_ffts2));
        
        
        end
        
        maxCorr1 = max(corr1(1:samplesPerCode));
        maxCorr2 = max(corr2(1:samplesPerCode));
        
        if maxCorr1>maxCorr2
            [X,refCodePhase]=max(corr1(1:samplesPerCode));
        else
            [X,refCodePhase]=max(corr2(1:samplesPerCode));
        end

        acqResults.codePhase(PRN)=refCodePhase;

        %Fine Frequency Search
        signal0DC = signal - mean(signal);

        %--- Generate 10msec long C/A codes sequence for given PRN --------
        caCode = generateCAcode(PRN);
        codeValueIndex = floor((ts * (1:10*samplesPerCode)) / ...
            (1/settings.codeFreqBasis));


        longCaCode = caCode((rem(codeValueIndex, 1023) + 1));

        %--- Remove C/A code modulation from the original signal ----------
        % (Using detected C/A code phase)
        xCarrier = ...
            signal0DC(acqResults.codePhase(PRN):(acqResults.codePhase(PRN) + 10*samplesPerCode-1)) ...
            .* longCaCode;

        %--- Find the next highest power of two and increase by 8x --------
        fftNumPts = 8*(2^(nextpow2(length(xCarrier))));

        %--- Compute the magnitude of the FFT, find maximum and the
        %associated carrier frequency

        fftxCarrier=fft(xCarrier, fftNumPts);
        Amp=fftshift(fftxCarrier.*conj(fftxCarrier));
        fftFreqBins=-samplingFreq/2:samplingFreq/fftNumPts:...
            samplingFreq/2-samplingFreq/fftNumPts;
        [v,indMin]=min(abs(fftFreqBins+acqCarrFreq+1000/cohCodePeriods));
        [v,indMax]=min(abs(fftFreqBins+acqCarrFreq-1000/cohCodePeriods));
        Amp2 = Amp;
        Amp2(1:indMin-1)=0;
        Amp2(indMax+1:end)=0;
        [v,maxInd] = max(Amp2);
        acqResults.carrFreq(PRN)  = -fftFreqBins(maxInd);
        
        % calculate the doppler of the code based on the doppler of the
        % carrier
        dopplerCarr=acqResults.carrFreq(PRN)-settings.IF;
        dopplerCode=dopplerCarr*settings.codeFreqBasis/1575.42e6;
        
        if settings.fileType == 2
            dopplerCode=-dopplerCode;
        end
        acqResults.codeRate(PRN)=settings.codeFreqBasis+dopplerCode;

    else
        fprintf('. ');
    end

end


fprintf(')\n');