function [navSolutions,X] = navSolution_s(navSolutions,trackResults,X,loopCnt,settings,eph)


 
[~,~,transmitTime]=...
    findTransTime(X.sampleNum,X.activeChnList,X.svTimeTable,trackResults);
if(X.currMeasNr==4)
    rxTime=max(transmitTime)+settings.startOffset/1000;
else
    rxTime = navSolutions.rxTime(X.currMeasNr-1) + settings.ms*settings.N/1000.0;
end
 
 
[navSolutions.channel.rawP(:, X.currMeasNr)] = calculatePseudoranges(...
    transmitTime,rxTime,X.activeChnList,settings); 
 
[satPositions, satClkCorr] = satpos(transmitTime(transmitTime>0), ...
    [trackResults(X.activeChnList).PRN],eph); 
freqforcal=zeros(1,length(X.activeChnList));
for ii=1:length(X.activeChnList)
    freqforcal(ii)=trackResults(1,X.activeChnList(ii)).carrFreq(loopCnt);
end

if size(X.activeChnList, 2) > 3
    
 
    [xyzdt,navSolutions.channel.el(X.activeChnList, X.currMeasNr), ...
        navSolutions.channel.az(X.activeChnList, X.currMeasNr), ...
        navSolutions.DOP(:, X.currMeasNr)] = ...
        leastSquarePos(satPositions, ...
        navSolutions.channel.rawP(X.activeChnList, X.currMeasNr)' + satClkCorr * settings.c, ...
        freqforcal,settings);
    navSolutions.X(X.currMeasNr)  = xyzdt(1);
    navSolutions.Y(X.currMeasNr)  = xyzdt(2);
    navSolutions.Z(X.currMeasNr)  = xyzdt(3);
    navSolutions.dt(X.currMeasNr) = xyzdt(4);
    navSolutions.Vx(X.currMeasNr)  = xyzdt(5);
    navSolutions.Vy(X.currMeasNr)  = xyzdt(6);
    navSolutions.Vz(X.currMeasNr)  = xyzdt(7);
    navSolutions.ddt(X.currMeasNr) = xyzdt(8);
    
    
 
    X.satElev = navSolutions.channel.el(:, X.currMeasNr);
 
    navSolutions.channel.correctedP(X.activeChnList, X.currMeasNr) = ...
        navSolutions.channel.rawP(X.activeChnList, X.currMeasNr) + ...
        satClkCorr' * settings.c - navSolutions.dt(X.currMeasNr);
 
    [navSolutions.latitude(X.currMeasNr), ...
        navSolutions.longitude(X.currMeasNr), ...
        navSolutions.height(X.currMeasNr)] = cart2geo(...
        navSolutions.X(X.currMeasNr), ...
        navSolutions.Y(X.currMeasNr), ...
        navSolutions.Z(X.currMeasNr), ...
        5);
 
    navSolutions.utmZone = findUtmZone(navSolutions.latitude(X.currMeasNr), ...
        navSolutions.longitude(X.currMeasNr));
 
    [navSolutions.E(X.currMeasNr), ...
        navSolutions.N(X.currMeasNr), ...
        navSolutions.U(X.currMeasNr)] = cart2utm(xyzdt(1), xyzdt(2), ...
        xyzdt(3), ...
        navSolutions.utmZone);
    
    if(X.currMeasNr<6)
        navSolutions.rxTime(X.currMeasNr)=rxTime-navSolutions.dt(X.currMeasNr)/settings.c;
    else
        navSolutions.rxTime(X.currMeasNr)=rxTime;
    end
%     navSolutions.rxTime(X.currMeasNr)=rxTime-navSolutions.dt(X.currMeasNr)/settings.c;
    navSolutions.absoluteSample(X.currMeasNr) =X.sampleNum;
    navSolutions.rawRxTime(X.currMeasNr)=rxTime;
    for ii=1:length(X.activeChnList) % 
        X.satPositions(1:3,ii) = e_r_corr((navSolutions.rxTime(X.currMeasNr)-transmitTime(X.activeChnList(ii))),satPositions(1:3,ii));
        X.satPositions(4:6,ii) = satPositions(4:6,ii);
%       X.satPositions(4:6,ii) = e_r_corr((navSolutions.rxTime(X.currMeasNr)-transmitTime(X.activeChnList(ii))),satPositions(4:6,ii));
    end
%     X.rawP = navSolutions.channel.correctedP(X.activeChnList, X.currMeasNr);
    X.rawP = navSolutions.channel.rawP(X.activeChnList, X.currMeasNr)' + satClkCorr * settings.c;
    X.rawdP = freqforcal*settings.c/1575.42e6;
 
    Cne=[-sin(navSolutions.latitude(X.currMeasNr))*cos(navSolutions.longitude(X.currMeasNr)), -sin(navSolutions.latitude(X.currMeasNr))*sin(navSolutions.longitude(X.currMeasNr)),  cos(navSolutions.latitude(X.currMeasNr));
        -sin(navSolutions.longitude(X.currMeasNr)),                cos(navSolutions.longitude(X.currMeasNr)),                 0;
        -cos(navSolutions.latitude(X.currMeasNr))*cos(navSolutions.longitude(X.currMeasNr)),  -cos(navSolutions.latitude(X.currMeasNr))*sin(navSolutions.longitude(X.currMeasNr)),  -sin(navSolutions.latitude(X.currMeasNr))];
    navSolutions.Vn(1:3,X.currMeasNr)= ...
        Cne*[navSolutions.Vx(X.currMeasNr);navSolutions.Vy(X.currMeasNr);navSolutions.Vz(X.currMeasNr)];
    % doppler aided
%     for ii=1:length(X.activeChnList)
%         lx = satPositions(1,ii) - navSolutions.X(X.currMeasNr);
%         ly = satPositions(2,ii) - navSolutions.Y(X.currMeasNr);
%         lz = satPositions(3,ii) - navSolutions.Z(X.currMeasNr);
%         norm_a = sqrt(lx*lx+ly*ly+lz*lz);
%         a=[lx;ly;lz]/norm_a;
%           X.Vd(ii) = (satPositions(4:6,ii)-SimTrack(4:6,X.currMeasNr))'*a/settings.c*1575.42e6;
%           X.Vd(X.activeChnList(ii)) = (satPositions(4:6,ii)- Cne'*LI.vn)'*a/settings.c*1575.42e6;
%     end
else
    disp(['   Measurement No. ', num2str(X.currMeasNr), ...
        ': Not enough information for position solution.']);
    navSolutions.X(X.currMeasNr)           = NaN;
    navSolutions.Y(X.currMeasNr)           = NaN;
    navSolutions.Z(X.currMeasNr)           = NaN;
    navSolutions.dt(X.currMeasNr)          = NaN;
    navSolutions.DOP(:, X.currMeasNr)      = zeros(5, 1);
    navSolutions.latitude(X.currMeasNr)    = NaN;
    navSolutions.longitude(X.currMeasNr)   = NaN;
    navSolutions.height(X.currMeasNr)      = NaN;
    navSolutions.E(X.currMeasNr)           = NaN;
    navSolutions.N(X.currMeasNr)           = NaN;
    navSolutions.U(X.currMeasNr)           = NaN;
    navSolutions.rawRxTime(X.currMeasNr)   = NaN;
    navSolutions.absoluteSample(X.currMeasNr) = NaN;
    navSolutions.rxTime(X.currMeasNr)       = NaN;

    navSolutions.channel.az(X.activeChnList, X.currMeasNr) = ...
        NaN(1, length(X.activeChnList));
    navSolutions.channel.el(X.activeChnList, X.currMeasNr) = ...
        NaN(1, length(X.activeChnList));
end
    
    
    
    