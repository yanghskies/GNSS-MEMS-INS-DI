function pseudoranges = calculatePseudoranges(...
                        transmitTime,rxTime,channelList,settings)
%calculatePseudoranges finds relative pseudoranges for all satellites
% �������ǵ����α��
%listed in CHANNELLIST at the specified millisecond of the processed
%signal. The pseudoranges contain unknown receiver clock offset. It can be
%found by the least squares position search procedure.
%
% function pseudoranges = calculatePseudoranges(...
%                         transmitTime,rxTime,channelList,settings)
%
%   Inputs:
%       transmitTime    - transmitting time all satellites on the list
%       rxTime          - receiver time 
%       channelList     - list of channels to be processed
%       settings        - receiver settings
%
%   Outputs:
%       pseudoranges    - relative pseudoranges to the satellites.
%--------------------------------------------------------------------------
%--- Set initial travel time to infinity ----------------------------------
% Later in the code a shortest pseudorange will be selected. Therefore
% pseudoranges from non-tracking channels must be the longest - e.g.
% infinite.
travelTime = inf(1, settings.numberOfChannels);
    
%--- For all channels in the list ...
for channelNr = channelList

    %--- Compute the travel times -----------------------------------------
    travelTime(channelNr) = rxTime-transmitTime(channelNr);
end

%--- Convert travel time to a distance ------------------------------------
% The speed of light must be converted from meters per second to meters
% per millisecond.
pseudoranges    = travelTime * settings.c;