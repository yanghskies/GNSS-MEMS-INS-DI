function BitSyncTime= findBitSync(trackRes,activeChnList,StartTime)

NumChan=length(activeChnList);
for ch = 1:NumChan
    for ii = StartTime:StartTime+1000
        if(sign(trackRes(activeChnList(ch)).I_P(ii)) ...
                ~= sign(trackRes(activeChnList(ch)).I_P(ii+1)))
            BitSyncTime(activeChnList(ch))=ii+1;
            break
        end
    end
    for ii = 1:50
        if(BitSyncTime(activeChnList(ch))<StartTime+20)
            break;
        else
            BitSyncTime(activeChnList(ch))=BitSyncTime(activeChnList(ch))-20;
        end
    end
end