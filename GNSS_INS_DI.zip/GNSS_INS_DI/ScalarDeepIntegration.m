clear all;
clc;
format ('compact');
format ('long', 'g');
addpath include;             %   
addpath geoFunctions;        %  
addpath INSFunctions;        %   
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%  
global parameter;
global Loop;
% INS
parameter.PI = 3.14159265358979323846 ;% pi
parameter.We =0.00007292115;%  
parameter.Re =6378137.0;%  
parameter.e  =0.003352813;
parameter.Con_d2r    =1.745329251994330e-002;   %  
parameter.Con_r2d    =5.729577951308232e+001;   %  
parameter.Con_dh2rs  =4.848136811095360e-006;   % d/h to rad/s 
parameter.c = 299792458;
% GPS
parameter.msToProcess = 223000;                 %  %[ms] 
parameter.fileName = '.\GPSL1_DataGen\GPSL1CA_0214DatagpsL1_229.995s_8bit.raw';% 
parameter.IF = 0e6;                %  
parameter.codeFreqBasis = 1.023e6; %  
parameter.codeLength = 1023;       %  
parameter.samplingFreq = 2.5e6;    % 
parameter.ms = 20;                 %  
parameter.N = floor(1000/parameter.ms);     %  
parameter.numberOfChannels = 11;   %  
parameter.Tu = 1e-3;               % 
parameter.FSN = parameter.samplingFreq*parameter.Tu; % 
parameter.B =  parameter.samplingFreq/2;      %  
parameter.T = parameter.Tu*parameter.ms;             %  
parameter.navSolRate         = 1000/parameter.ms/parameter.N;   %  
parameter.skipNumberOfSamples     = 0*2.5e6;
parameter.dataType = 'int8';
parameter.fileType = 2;
%%  
parameter.dllDampingRatio         = 0.7;  %  
parameter.dllNoiseBandwidth       = 1;    %     %[Hz]
parameter.dllCorrelatorSpacing    = 0.2;  %    %[chips]
 
parameter.pllDampingRatio         = 0.7;  %  
parameter.pllNoiseBandwidth       = 10;   %      %5��18;      %[Hz]
 
parameter.fllDampingRatio         = 0.7;  % 
parameter.fllNoiseBandwidth       = 10;   %      %3��10;      %[Hz]
 
parameter.startOffset = 68.802;       %[ms] Initial sign. travel time  
parameter.CNo.accTime = 0.001;% Accumulation interval in Tracking (in Sec)  
parameter.CNo.enableVSM = 1;  % Show C/No during Tracking;1-on;0-off;  
parameter.CNo.VSMinterval = 1000;% 400;% Accumulation interval for computing VSM C/No (in ms) VSM  
parameter.CNo.PRM_K=200;       % Accumulation interval for computing PRM C/No (in ms)  PRM  
parameter.CNo.PRM_M=20;        % No. of samples to calculate narrowband power;          
parameter.CNo.MOMinterval=200; % Accumulation interval for computing MOM C/No (in ms)  MOM 
 
parameter.elevationMask      = 10;           %[degrees 0 - 90]
% Enable/dissable use of tropospheric correction  
parameter.useTropCorr        = 0;            % 0 - Off
% Loop  
Loop.start = 607;%[ms]
Loop.LIstart = 30000/parameter.ms/parameter.N;%30000/parameter.ms;%[ms] 30000/20/50  
Loop.N = floor(parameter.msToProcess/parameter.ms);% 210000/20 10500
%% PLL FLL DLL 
a_LF = 1.1; % 
b_LF = 2.4;
K_temp_LF = (a_LF*b_LF^2+a_LF^2-b_LF)/(4*(a_LF*b_LF-1));
wn=parameter.pllNoiseBandwidth/K_temp_LF;
 
xi_FLL = 0.707;
wn_FLL = 2*parameter.fllNoiseBandwidth/(xi_FLL+1/(4*xi_FLL));
Loop.T_coh = parameter.Tu*parameter.ms;
Loop.C1 = 1/Loop.T_coh * (8*b_LF*wn*Loop.T_coh+2*wn^3*Loop.T_coh^3) /...% SU Filter Only: PLL Filter Coefficients  P18
    (4*b_LF*wn*Loop.T_coh+2*a_LF*wn^2*Loop.T_coh^2+wn^3*Loop.T_coh^3+8);
Loop.C2 = 1/Loop.T_coh * (8*a_LF*wn^2*Loop.T_coh^2-4*wn^3*Loop.T_coh^3) /...
    (4*b_LF*wn*Loop.T_coh+2*a_LF*wn^2*Loop.T_coh^2+wn^3*Loop.T_coh^3+8);
Loop.C3 = 1/Loop.T_coh * (8*wn^3*Loop.T_coh^3) /...
    (4*b_LF*wn*Loop.T_coh+2*a_LF*wn^2*Loop.T_coh^2+wn^3*Loop.T_coh^3+8);    
Loop.C1_FLL = 1/Loop.T_coh * (8*xi_FLL*wn_FLL*Loop.T_coh) /...% SU Filter Only: FLL Filter Coefficients
    (4+4*xi_FLL*wn_FLL*Loop.T_coh+(wn_FLL*Loop.T_coh)^2);
Loop.C2_FLL = 1/Loop.T_coh * (4*(wn_FLL*Loop.T_coh)^2) /...
    (4+4*xi_FLL*wn_FLL*Loop.T_coh+(wn_FLL*Loop.T_coh)^2); 
Loop.earlyLateSpc = parameter.dllCorrelatorSpacing;
Loop.PDIcode = 0.001*parameter.ms;
 
[Loop.tau1code, Loop.tau2code] = calcLoopCoef(parameter.dllNoiseBandwidth,parameter.dllDampingRatio,1.0);  
                                
%  Loop.PDIcarr = 0.001*parameter.ms;
% [Loop.tau1carr, Loop.tau2carr] = calcLoopCoef(parameter.pllNoiseBandwidth, ...
%                                     parameter.pllDampingRatio,0.25);
 
if (parameter.fileType==1)
    Loop.dataAdaptCoeff=1;
else
    Loop.dataAdaptCoeff=2;
end
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% Init channels and trackingResults  
[fid, message] = fopen(parameter.fileName, 'rb');
if(fid>0)
    load '.\GNSS_SDR_int8\eph.mat';
    load '.\Init.mat';
    load '.\IMUdata.mat';
%     load IP.mat;
%%  
    [LI,I] = LIInit();
    %  
%      
end
channel.PRN = 0;
channel.status = 0;
channel.caCode = zeros(1, 1025);
channel.codeFreq = 0;
channel.dcodeFreq = 0;
channel.remCodePhase  = 0;
channel.carrFreq = 0;
channel.dcarrFreq = 0;
channel.carrFreqBasis =0;
channel.carrJust = 0;
channel.remCarrPhase  =0;
channel.codeNco   = 0;
channel.codeError = 0;
channel.carrNco   = 0;
channel.carrError = 0;
channel.oldCodeNco   = 0;% 
channel.oldCodeError = 0;% 
channel.oldCarrNco   = 0;% 
channel.oldCarrError = 0;% 
channel.codePhaseStep = 0; 
channel.blksize =0;%  
channel.samplepos=0;%  
channel.I_E=0.0;
channel.I_P=0.0;
channel.I_L=0.0;
channel.Q_E=0.0;
channel.Q_P=0.0;
channel.Q_L=0.0;
channel.LF_t1 = 0;
channel.LF_t2 = 0;
channel.LF_t3 = 0;
channel.LF_t4 = 0;
channel = repmat(channel, 1, parameter.numberOfChannels);
 
for m = 1:parameter.numberOfChannels
    channel(m).PRN = Init.PRN(m);
    channel(m).status = Init.status(m);
    if (channel(m).PRN ~= 0)
        channel(m).caCode = generateCAcode(channel(m).PRN);
        channel(m).caCode = [channel(m).caCode(1023) channel(m).caCode channel(m).caCode(1)];%  
        channel(m).codeFreq = Init.codeFreq(m);
        channel(m).dcodeFreq = 0;
        channel(m).remCodePhase  = Init.remCodePhase(m);
        channel(m).carrFreq = Init.carrFreq(m);
        channel(m).dcarrFreq = 0;
        channel(m).carrFreqBasis = Init.carrFreqBasis(m);
        channel(m).carrJust = 0;
        channel(m).remCarrPhase  = Init.remCarrPhase(m);
        channel(m).codeNco   = 0;
        channel(m).codeError = 0;
        channel(m).carrNco   = 0;
        channel(m).carrError = 0;
        channel(m).oldCodeNco   = 0;% 
        channel(m).oldCodeError = 0;% 
        channel(m).oldCarrNco   = 0;%
        channel(m).oldCarrError = 0;%
        channel(m).codePhaseStep = channel(m).codeFreq / parameter.samplingFreq;%  
        channel(m).blksize = ceil((parameter.codeLength-channel(m).remCodePhase) / channel(m).codePhaseStep);%  
        channel(m).samplepos=ceil(Init.initSamplePos(m));%  
        channel(m).I_E=0.0;
        channel(m).I_P=0.0;
        channel(m).I_L=0.0;
        channel(m).Q_E=0.0;
        channel(m).Q_P=0.0;
        channel(m).Q_L=0.0;
        channel(m).LF_t1 = 0;
        channel(m).LF_t2 = 0;
        channel(m).LF_t3 = 0;
        channel(m).LF_t4 = 0; 
    end
end
%%  
trackResults.status         = '-';           % No tracked signal, or lost lock
trackResults.absoluteSample = zeros(1, Loop.N); %  
trackResults.codeFreq       = inf(1, Loop.N);
trackResults.remCodePhase   = zeros(1, Loop.N);
trackResults.carrFreq       = inf(1, Loop.N);
trackResults.Vd             = zeros(1, Loop.N);
trackResults.remCarrPhase   = zeros(1, Loop.N);
trackResults.I_P            = zeros(1, Loop.N);
trackResults.I_E            = zeros(1, Loop.N);
trackResults.I_L            = zeros(1, Loop.N);
trackResults.Q_E            = zeros(1, Loop.N);
trackResults.Q_P            = zeros(1, Loop.N);
trackResults.Q_L            = zeros(1, Loop.N);
trackResults.dllDiscr       = inf(1, Loop.N);
trackResults.dllDiscrFilt   = inf(1, Loop.N);
trackResults.pllDiscr       = inf(1, Loop.N);
trackResults.pllDiscrFilt   = inf(1, Loop.N);
% trackResults.CNo.VSMValue = ...
%     zeros(1,floor(S.msToProcess/S.CNo.VSMinterval));
% trackResults.CNo.VSMIndex = ...
%     zeros(1,floor(S.msToProcess/parameter.CNo.VSMinterval));
trackResults = repmat(trackResults, 1, parameter.numberOfChannels);
for m = 1:parameter.numberOfChannels
    if (channel(m).PRN ~= 0)
        trackResults(m).PRN     = channel(m).PRN;
        trackResults(m).status  = channel(m).status;
    end
end 
%% 
Loop.vsmCnt=0;
Loop.satElev = inf(1, parameter.numberOfChannels);
Loop.Vd = zeros(1, parameter.numberOfChannels);
Loop.Vdt = zeros(1, parameter.numberOfChannels);
Loop.Vdt_old = zeros(1, parameter.numberOfChannels);
Loop.activeChnList = find([trackResults.status] ~= '-');
Loop.readyChnList = Loop.activeChnList;
Loop.svTimeTable=transTimeTable(Loop.activeChnList,trackResults,subFrameStart,TOW,parameter);
Loop.navStep = 1000/parameter.ms/parameter.navSolRate;
Loop.currMeasNr = 0;
Loop.currINS = 0;
Loop.sample_clk_bias_shift = 50;
sampleNum0 = parameter.skipNumberOfSamples+min( Init.initSamplePos)-Loop.sample_clk_bias_shift;

%% start data process
startTime = now; 
fprintf(' ��%f\n',startTime);
for loopCnt =  1:parameter.msToProcess
    % 
    fprintf(' %dms\n',loopCnt);
    % tracking
    for m = 1:parameter.numberOfChannels
        if(m==1)
            minpos = channel(m).samplepos;
            maxpos = channel(m).samplepos;
            maxblksize = channel(m).blksize;
        else
            if(minpos>channel(m).samplepos)
                minpos = channel(m).samplepos;
            end
            if(maxpos<channel(m).samplepos)
                maxpos = channel(m).samplepos;
            end
            if(maxblksize<channel(m).blksize)
                maxblksize = channel(m).blksize;
            end
        end
    end
    fseek(fid, Loop.dataAdaptCoeff*(minpos-1),'bof');
    %% 
    [rawSignal0, samplesRead0] = fread(fid,Loop.dataAdaptCoeff*(maxpos-minpos+maxblksize), parameter.dataType);
    %%  %%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%
    for m = 1:parameter.numberOfChannels
        %  
        rawSignal = rawSignal0((channel(m).samplepos-minpos)*Loop.dataAdaptCoeff...
            +1:(channel(m).samplepos-minpos+channel(m).blksize)*Loop.dataAdaptCoeff)';    
        Pn=100;
        CN_down = 0;%33
%         if(loopCnt<50000)
%             ;
%         elseif(loopCnt>=50000&&loopCnt<100000)
%             rawSignal = (rawSignal/sqrt(10^(CN_down*(loopCnt-50000)/50000/10))) + sqrt(Pn^2-Pn^2./(10.^(CN_down*(loopCnt-50000)/50000/10)))*randn(1,length(rawSignal));
%         else
%             rawSignal = (rawSignal/sqrt(10^(CN_down/10))) + sqrt(Pn^2-Pn^2./(10.^(CN_down/10)))*randn(1,length(rawSignal));
%         end

%         if(loopCnt<10000)
%             ;
%         elseif(loopCnt>=10000&&loopCnt<20000)
%             rawSignal = (rawSignal/sqrt(10^(CN_down*(loopCnt-10000)/10000/10))) + sqrt(Pn^2-Pn^2./(10.^(CN_down*(loopCnt-10000)/10000/10)))*randn(1,length(rawSignal));
%         else
%             rawSignal = (rawSignal/sqrt(10^(CN_down/10))) + sqrt(Pn^2-Pn^2./(10.^(CN_down/10)))*randn(1,length(rawSignal));
%         end  
        
        if (Loop.dataAdaptCoeff==2)
            rawSignal1=rawSignal(1:2:end);
            rawSignal2=rawSignal(2:2:end);
            rawSignal = rawSignal1 + 1i .* rawSignal2;  % transpose vector
        end
        
        if(Loop.currMeasNr < Loop.LIstart)
            % 
            channel(m).carrFreq = channel(m).carrFreqBasis + channel(m).carrNco;
        elseif(Loop.currMeasNr == Loop.LIstart)
%           channel(m).carrFreq =channel(m).carrJust+ Loop.Vd(m);
              
            channel(m).carrFreq =channel(m).carrJust+ Loop.Vd0(m)+(channel(m).samplepos-sampleNum0)/parameter.FSN*channel(m).dcarrFreq;
            channel(m).LF_t1 = 0;
            channel(m).LF_t2 = 0;
            channel(m).LF_t3 = 0;
            channel(m).LF_t4 = 0;
        else
 
        channel(m).carrFreq =channel(m).carrJust + channel(m).carrNco + Loop.Vd0(m)+(channel(m).samplepos-sampleNum0)/parameter.FSN*channel(m).dcarrFreq;
        end
 
        channel(m).codeFreq = parameter.codeFreqBasis - channel(m).codeNco - channel(m).carrFreq/1540;
 
        tcode=(channel(m).remCodePhase-Loop.earlyLateSpc):channel(m).codePhaseStep:((channel(m).blksize-1)*channel(m).codePhaseStep+channel(m).remCodePhase-Loop.earlyLateSpc);
        tcode2 = ceil(tcode)+1;
        earlyCode=channel(m).caCode(tcode2);
        tcode=(channel(m).remCodePhase+Loop.earlyLateSpc):channel(m).codePhaseStep:((channel(m).blksize-1)*channel(m).codePhaseStep+channel(m).remCodePhase+Loop.earlyLateSpc);
        tcode2 = ceil(tcode)+1;
        lateCode=channel(m).caCode(tcode2);
        tcode=channel(m).remCodePhase:channel(m).codePhaseStep:((channel(m).blksize-1)*channel(m).codePhaseStep+channel(m).remCodePhase);
        tcode2 = ceil(tcode)+1;
        promptCode=channel(m).caCode(tcode2);
        channel(m).remCodePhase = (tcode(channel(m).blksize)+channel(m).codePhaseStep)-1023.0;
 
        time   = (0:channel(m).blksize) ./ parameter.samplingFreq;
        trigarg=((channel(m).carrFreq*2.0*pi).*time)+channel(m).remCarrPhase;
        channel(m).remCarrPhase = rem(trigarg(channel(m).blksize+1),(2*pi));
        carrsig=exp(1i.*trigarg(1:channel(m).blksize));
        qBasebandSignal = real(carrsig.*rawSignal);
        iBasebandSignal = imag(carrsig.*rawSignal);
        I_E = sum(earlyCode  .* iBasebandSignal);
        Q_E = sum(earlyCode  .* qBasebandSignal);
        I_P = sum(promptCode .* iBasebandSignal);
        Q_P = sum(promptCode .* qBasebandSignal);
        I_L = sum(lateCode   .* iBasebandSignal);
        Q_L = sum(lateCode   .* qBasebandSignal);
       
        channel(m).I_E=channel(m).I_E+I_E;
        channel(m).I_P=channel(m).I_P+I_P;
        channel(m).I_L=channel(m).I_L+I_L;
        channel(m).Q_E=channel(m).Q_E+Q_E;
        channel(m).Q_P=channel(m).Q_P+Q_P;
        channel(m).Q_L=channel(m).Q_L+Q_L;
   
        if(mod(loopCnt,parameter.ms)==0)
            if(loopCnt==parameter.ms)
                channel(m).I_P1=channel(m).I_P;
                channel(m).Q_P1=channel(m).Q_P;
                FLL=0;
            else
                dot=channel(m).I_P1*channel(m).I_P+channel(m).Q_P1*channel(m).Q_P;          %  
                crossProduct=channel(m).I_P1*channel(m).Q_P-channel(m).I_P*channel(m).Q_P1; %  
         
                FLL = crossProduct*sign(dot)/(2*pi*(channel(m).I_P*channel(m).I_P+channel(m).Q_P*channel(m).Q_P));
                channel(m).I_P1 = channel(m).I_P;
                channel(m).Q_P1 = channel(m).Q_P;
            end
            channel(m).carrError = atan(channel(m).Q_P / channel(m).I_P) / (2.0 * pi); % cycle
             
            PD_output = channel(m).carrError;
            
            FD_output = FLL;
            
            channel(m).LF_t1 = channel(m).LF_t1 + PD_output * Loop.C3 + FD_output * Loop.C2_FLL * Loop.T_coh;
            channel(m).LF_t2 = channel(m).LF_t1 + PD_output * Loop.C2 + FD_output * Loop.C1_FLL * Loop.T_coh;
            channel(m).LF_t3 = channel(m).LF_t3 + channel(m).LF_t2;
            channel(m).LF_t4 = channel(m).LF_t3 + PD_output * Loop.C1;
            channel(m).carrNco = channel(m).LF_t4;
%           channel(m).carrFreq = channel(m).carrFreqBasis + channel(m).carrNco;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%question????
          
            channel(m).codeError = (sqrt(channel(m).I_E * channel(m).I_E + channel(m).Q_E * channel(m).Q_E)...
                - sqrt(channel(m).I_L * channel(m).I_L + channel(m).Q_L * channel(m).Q_L)) / ...
                (sqrt(channel(m).I_E * channel(m).I_E + channel(m).Q_E * channel(m).Q_E)...
                + sqrt(channel(m).I_L * channel(m).I_L + channel(m).Q_L * channel(m).Q_L));
       
            channel(m).codeNco = channel(m).oldCodeNco + (Loop.tau2code/Loop.tau1code) * ...
                (channel(m).codeError - channel(m).oldCodeError) + ...
                channel(m).codeError * (Loop.PDIcode/Loop.tau1code);
            channel(m).oldCodeNco   = channel(m).codeNco;
            channel(m).oldCodeError = channel(m).codeError;
%           channel(m).codeFreq = parameter.codeFreqBasis - channel(m).codeNco - channel(m).carrFreq/1540;
            channel(m).I_E=0.0;
            channel(m).I_P=0.0;
            channel(m).I_L=0.0;
            channel(m).Q_E=0.0;
            channel(m).Q_P=0.0;
            channel(m).Q_L=0.0;
        end

        channel(m).samplepos = channel(m).samplepos+channel(m).blksize;
        channel(m).codePhaseStep = channel(m).codeFreq / parameter.samplingFreq;
        channel(m).blksize = ceil((parameter.codeLength-channel(m).remCodePhase)/channel(m).codePhaseStep);

        trackResults(m).codeFreq(loopCnt) = channel(m).codeFreq;
        trackResults(m).remCodePhase(loopCnt) = channel(m).remCodePhase;
        trackResults(m).carrFreq(loopCnt) = channel(m).carrFreq;
        trackResults(m).remCarrPhase(loopCnt) = channel(m).remCarrPhase;
        trackResults(m).I_E(loopCnt) = I_E;
        trackResults(m).I_P(loopCnt) = I_P;
        trackResults(m).I_L(loopCnt) = I_L;
        trackResults(m).Q_E(loopCnt) = Q_E;
        trackResults(m).Q_P(loopCnt) = Q_P;
        trackResults(m).Q_L(loopCnt) = Q_L;
        trackResults(m).dllDiscr(loopCnt) = channel(m).codeError;
        trackResults(m).dllDiscrFilt(loopCnt) = channel(m).codeNco;
        trackResults(m).pllDiscr(loopCnt) = channel(m).carrError;
        trackResults(m).pllDiscrFilt(loopCnt) = channel(m).carrNco;
        trackResults(m).absoluteSample(loopCnt) = channel(m).samplepos-channel(m).remCodePhase/channel(m).codePhaseStep;
        trackResults(m).Vd(loopCnt) = Loop.Vd(m);
    end % for m = 1:parameter.numberOfChannels
 
     % CN0 and lock-detection 
    if (parameter.CNo.enableVSM == 1)
        if (rem(loopCnt,parameter.CNo.VSMinterval)==0) %  
            Loop.vsmCnt = Loop.vsmCnt+1;
            for m = 1:parameter.numberOfChannels
                CNoValue=CNoVSM(trackResults(m).I_P(loopCnt-parameter.CNo.VSMinterval+1:loopCnt),...
                    trackResults(m).Q_P(loopCnt-parameter.CNo.VSMinterval+1:loopCnt),parameter.CNo.accTime); %  
                trackResults(m).CNo.VSMValue(Loop.vsmCnt) = CNoValue;
                trackResults(m).CNo.VSMIndex(Loop.vsmCnt) = loopCnt;
            end
        end
    end
  
    if(mod(loopCnt,parameter.ms*parameter.N)==0) % parameter.ms*parameter.N = 1000   
        Loop.currMeasNr = Loop.currMeasNr+1;
        Loop.sampleNum=floor(Loop.currMeasNr*parameter.samplingFreq/parameter.navSolRate...
            +parameter.skipNumberOfSamples+min(Init.initSamplePos))-Loop.sample_clk_bias_shift;
        %                   currMeasNr*2.5e6+0+min(Init.initSamplePos))-50
 
        if(Loop.currMeasNr>3)
            Loop.activeChnList = intersect(find(Loop.satElev >= parameter.elevationMask), ...
                Loop.readyChnList);
%             Loop.activeChnList = [1,3,5,6,7];
            navSolutions.channel.PRN(Loop.activeChnList, Loop.currMeasNr) = ...
                [trackResults(Loop.activeChnList).PRN];
            navSolutions.channel.el(:, Loop.currMeasNr) = NaN(parameter.numberOfChannels, 1);
            navSolutions.channel.az(:, Loop.currMeasNr) = NaN(parameter.numberOfChannels, 1);
            [navSolutions,Loop] = navSolution_s(navSolutions,trackResults,Loop,loopCnt,parameter,eph);
 
 
        end
    % Loose Integrated  
        if(Loop.currMeasNr>5) %  
            for m = 1:parameter.numberOfChannels
%                 LI.R(m,m) = 293^2/2/(parameter.ms*parameter.Tu*10^(trackResults(m).CNo.VSMValue(end)/10))^2 + ...
%                     293^2/4/(parameter.ms*parameter.Tu*10^(trackResults(m).CNo.VSMValue(end)/10));
          
                LI.R(m,m) = (parameter.c/1.023e6)^2*2*parameter.dllCorrelatorSpacing/(4*parameter.ms*parameter.Tu*10^(trackResults(m).CNo.VSMValue(end)/10))*(1+2/(2-2*parameter.dllCorrelatorSpacing)/(parameter.ms*parameter.Tu*10^(trackResults(m).CNo.VSMValue(end)/10)));
                LI.R(m+parameter.numberOfChannels,m+parameter.numberOfChannels) = (parameter.c/(parameter.PI*parameter.ms*parameter.Tu*1575.42e6))^2*(2/(parameter.ms*parameter.Tu*10^(trackResults(m).CNo.VSMValue(end)/10))^2 + ...
                    2/(parameter.ms*parameter.Tu*10^(trackResults(m).CNo.VSMValue(end)/10)));
            end
               [LI,I] = LIKalman(LI,I,Loop);
            if(Loop.currMeasNr > Loop.LIstart) %  
                % 
                sampleNum0 = loopCnt*parameter.samplingFreq/1000+parameter.skipNumberOfSamples+min(Init.initSamplePos)-Loop.sample_clk_bias_shift;
                [index_a,index_b,transmitTime0]= findTransTime(sampleNum0,Loop.readyChnList,Loop.svTimeTable,trackResults);
                [satPositions0, satClkCorr0] = satpos(transmitTime0,[trackResults(Loop.readyChnList).PRN],eph);
                [nRn,nRe,gn,Wie,Wep] = EarthCalc(LI.latitude,LI.height,LI.vn);
                Ntemp=parameter.Re/sqrt(1-parameter.e*(2-parameter.e)*sin(LI.latitude)*sin(LI.latitude));
                LI.X=(Ntemp+LI.height)*cos(LI.latitude)*cos(LI.longitude);
                LI.Y=(Ntemp+LI.height)*cos(LI.latitude)*sin(LI.longitude);
                LI.Z=(Ntemp*(1-parameter.e)*(1-parameter.e)+LI.height)*sin(LI.latitude);
                for m =1:length(Loop.readyChnList)  %1:parameter.numberOfChannels
                    lx = satPositions0(1,m) - LI.X;
                    ly = satPositions0(2,m) - LI.Y;
                    lz = satPositions0(3,m) - LI.Z;
                    norm_a = sqrt(lx*lx+ly*ly+lz*lz);
                    a=[lx;ly;lz]/norm_a;
                    
                    channel(m).carrJust = channel(m).carrJust - (I.Cne'*LI.vnError)'*a/parameter.c*1575.42e6;
                end
            end
        end
    
%         Save_pos(:,Loop.currMeasNr)=[LI.latitude;LI.longitude;LI.height];
%         Save_vn(:,Loop.currMeasNr)=LI.vn;
%         Save_phi(:,Loop.currMeasNr)=DCM2Euler(I.Cnb,LI.gama);
%         LI.sita=Save_phi(1,Loop.currMeasNr);LI.gama=Save_phi(2,Loop.currMeasNr);LI.psi=Save_phi(3,Loop.currMeasNr);
    end
    if(mod(loopCnt,10)==0)
        if(Loop.currMeasNr>3)
            sampleNum0 = loopCnt*parameter.samplingFreq/1000+parameter.skipNumberOfSamples+min(Init.initSamplePos)-Loop.sample_clk_bias_shift;
            %
            [index_a,index_b,transmitTime0]= findTransTime(sampleNum0,Loop.readyChnList,Loop.svTimeTable,trackResults);
            [satPositions0, satClkCorr0] = satpos(transmitTime0,[trackResults(Loop.readyChnList).PRN],eph);
            [nRn,nRe,gn,Wie,Wep] = EarthCalc(LI.latitude,LI.height,LI.vn);
            Ntemp=parameter.Re/sqrt(1-parameter.e*(2-parameter.e)*sin(LI.latitude)*sin(LI.latitude));
            LI.X=(Ntemp+LI.height)*cos(LI.latitude)*cos(LI.longitude);
            LI.Y=(Ntemp+LI.height)*cos(LI.latitude)*sin(LI.longitude);
            LI.Z=(Ntemp*(1-parameter.e)*(1-parameter.e)+LI.height)*sin(LI.latitude);
            for m =1:length(Loop.readyChnList)  %1:parameter.numberOfChannels
                lx = satPositions0(1,m) - LI.X; 
                ly = satPositions0(2,m) - LI.Y;
                lz = satPositions0(3,m) - LI.Z;
                norm_a = sqrt(lx*lx+ly*ly+lz*lz);
                a=[lx;ly;lz]/norm_a;
                Loop.Vd0(m) = (satPositions0(4:6,m)- I.Cne'*LI.vn)'*a/parameter.c*1575.42e6; % ������Ƶ������
            end
        end
        
        Loop.currINS = Loop.currINS+1;
         
        [LI,I] = INSCycle2(LI,I,Loop,IMUdata);
        
        if(Loop.currMeasNr>3)
            transmitTime1 = transmitTime0 + 0.02;
            [satPositions1, satClkCorr1] = satpos(transmitTime1,[trackResults(Loop.readyChnList).PRN],eph);
            [nRn,nRe,gn,Wie,Wep] = EarthCalc(LI.latitude,LI.height,LI.vn);
            Ntemp=parameter.Re/sqrt(1-parameter.e*(2-parameter.e)*sin(LI.latitude)*sin(LI.latitude));
            LI.X=(Ntemp+LI.height)*cos(LI.latitude)*cos(LI.longitude);
            LI.Y=(Ntemp+LI.height)*cos(LI.latitude)*sin(LI.longitude);
            LI.Z=(Ntemp*(1-parameter.e)*(1-parameter.e)+LI.height)*sin(LI.latitude);
            for m = 1:length(Loop.readyChnList)
                lx = satPositions1(1,m) - LI.X;
                ly = satPositions1(2,m) - LI.Y;
                lz = satPositions1(3,m) - LI.Z;
                norm_a = sqrt(lx*lx+ly*ly+lz*lz);
                a=[lx;ly;lz]/norm_a;
                Loop.Vd1(m) = (satPositions1(4:6,m)- I.Cne'*LI.vn)'*a/parameter.c*1575.42e6;
                channel(m).dcarrFreq = (Loop.Vd1(m)-Loop.Vd0(m))/10;%   10ms?
            %     channel(m).dcodeFreq = -(Loop.Vd1(m)-Loop.Vd0(m))/20/1540;
            end
            %     Loop.Vd = Loop.Vd0;
        end
        Save_pos(:,Loop.currINS) = [LI.latitude;LI.longitude;LI.height];
        Save_vn(:,Loop.currINS)  = LI.vn;
        Save_phi(:,Loop.currINS) = [LI.sita;LI.gama;LI.psi];
    end
    if(Loop.currMeasNr>4)
        Loop.Vdt_old = Loop.Vd;
        if(mod(loopCnt,10)==0 && loopCnt>10)
            Loop.Vdt = Loop.Vd0 + (Loop.Vd1-Loop.Vd0)/10;
        elseif(loopCnt>10)
            Loop.Vdt = Loop.Vdt + (Loop.Vd1-Loop.Vd0)/10;
        end
        Loop.Vd = Loop.Vdt;
%     Loop.Vd = 99/100*Loop.Vdt_old + 1/100* Loop.Vdt;
    end
end
fclose(fid);
trackResults = calculateCNoPRM(trackResults,parameter);
trackResults = calculateCNoMOM(trackResults,parameter);
save('trackingResultsEnd', ...
        'trackResults', 'parameter', 'channel');
save('navSolutions','navSolutions','eph','Loop')
save('saveINS','Save_pos','Save_vn','Save_phi');